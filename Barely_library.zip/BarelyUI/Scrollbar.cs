﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using System.Diagnostics;
using Barely.Util;
using BarelyUI.Styles;

namespace BarelyUI
{
    public class Scrollbar : UIElement
    {
        public static readonly int SIZE = 26;
        
        Handle handle;

        protected int maxHeight;
        protected int sizeDifference;

        public Scrollbar()
        {
            autoAdjustPosSizeOfChilds = false;
            ignoreScrollOffset = true;
            Padding = new Point(4, 4);
            handle = new Handle(this);
            AddChild(handle);
            sprite = Style.GetActiveStyle().GetScrollbarSprite();
        }

        public override Point CalculateMinSize(Canvas canvas)
        {
            MinSize = new Point(SIZE, SIZE);
            return MinSize;
        }

        public override void SetSizeAndPosition(Canvas canvas, Point position, Point size)
        {
            base.SetSizeAndPosition(canvas, position, size);
            Debug.Assert(maxHeight > 0, "SetHeights must be called before SetSizeAndPosition");

            int visibleSize = maxHeight - sizeDifference;
            float per = visibleSize / (float)maxHeight;
            Point handleSize = new Point(Size.X - 2 * Padding.X, (int)(per * (Size.Y - 2 * Padding.Y)));
            handle.SetSizeAndPosition(canvas, Padding, handleSize);
            handle.SetMinMax(Padding.Y, Size.Y - Padding.Y - handleSize.Y);
        }

        public void SetHeights(int maxHeight, int sizeDifference)
        {
            this.sizeDifference = sizeDifference;
            this.maxHeight = maxHeight;
        }

        public float GetScrollValue()
        {
            return handle.GetRelativePosition();
        }

        class Handle : UIElement
        {
            Scrollbar scrollbarParent;
            Color colorNormal;
            Color colorMouseOver;

            int minY;
            int maxY;
            private Point mouseDownPosition;

            public Handle(Scrollbar scrollbarParent)
            {
                hasMouseDownFocus   = true;
                ignoreScrollOffset  = true;
                this.scrollbarParent= scrollbarParent;                
                layoutSizeX         = LayoutSize.MatchParent;
                layoutSizeY         = LayoutSize.MatchParent;
                var style           = Style.GetActiveStyle();
                sprite              = style.GetScrollbarHandleSprite();
                Color[] colors      = style.GetButtonColors();
                colorNormal         = colors[0];
                colorMouseOver      = colors[1];                
            }

            public override Point CalculateMinSize(Canvas canvas)
            {
                MinSize = new Point(12, 12);
                return MinSize;
            }

            public override void Update(float deltaTime)
            {
                base.Update(deltaTime);
                //Debug.WriteLine(Position);
            }

            public override void MouseEnter()
            {
                base.MouseEnter();
                color = colorNormal;
            }

            public override void MouseExit()
            {
                base.MouseEnter();
                color = colorMouseOver;
            }

            public void SetMinMax(int minY, int maxY)
            {
                this.minY = minY;
                this.maxY = maxY;
            }

            public float GetRelativePosition()
            {
                if (maxY - minY == 0)
                    return 0f;
                else 
                    return (float)(Position.Y - minY) / (float)(maxY - minY);
            }

            public override void LeftMouseStillPressed(Point localMousePos)
            {
                localMousePos += Position + scrollOffset;
                Point p = new Point(Position.X, localMousePos.Y - mouseDownPosition.Y);
                if (p.Y < minY)
                    p.Y = minY;
                if (p.Y > maxY)
                    p.Y = maxY;
                Position = p;
            }

            public override void LeftMouseDown(Point localMousePos)
            {
                base.LeftMouseDown(localMousePos);
                mouseDownPosition = localMousePos - Position - scrollOffset;
                Debug.WriteLine(mouseDownPosition);
            }

        }
    }
}
