﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using BarelyUI.Styles;
using BarelyUI.Layouts;

namespace BarelyUI
{
    public class KeyValueText : UIElement
    {
        private Text keyText;
        private Text valueText;
        private float sizeSplitKey;
        private float sizeSplitValue;

        public KeyValueText(string textId, string valueTextId)
        {
            var style = Style.GetActiveStyle();
            var layout = Layout.GetActiveLayout();

            autoAdjustPosSizeOfChilds = false;
            Interactable    = false;
            layoutSizeX     = layout.GetKeyValueTextLayoutSizeX();
            layoutSizeY     = layout.GetKeyValueTextLayoutSizeY();
            Padding         = layout.GetKeyValueTextPadding();
            sizeSplitKey    = layout.GetKeyValueTextSizeSplitKey();
            sizeSplitValue  = layout.GetKeyValueTextSizeSplitValue();


            keyText     = new Text(textId, style.GetKeyFont(), style.GetKeyTextColor()).SetAllignments(Allignment.Left, Allignment.Middle);
            valueText   = new Text(valueTextId, style.GetKeyFont(), style.GetKeyTextColor(), false).SetAllignments(Allignment.Right, Allignment.Middle);

            keyText.layoutSizeX   = LayoutSize.MatchParent;
            valueText.layoutSizeX = LayoutSize.MatchParent;
            childElements.Add(keyText);
            childElements.Add(valueText);
        }

        public void SetText(string textId)
        {
            keyText.SetText(textId);
        }

        public void SetValue(string newText)
        {
            valueText.SetText(newText);
        }

        public KeyValueText SetKeyColor(Color c)
        {
            keyText.SetColor(c);
            return this;
        }

        public KeyValueText SetValueColor(Color c)
        {
            valueText.SetColor(c);
            return this;
        }

        public override Point CalculateMinSize(Canvas canvas)
        {
            Point min1 = keyText.CalculateMinSize(canvas);
            Point min2 = valueText.CalculateMinSize(canvas);
            MinSize = new Point(min1.X + min2.X * 2, Math.Max(min1.Y, min2.Y));
            WrappingMinSize = MinSize;
            return MinSize;                                                    
        }      

        public override void SetSizeAndPosition(Canvas canvas, Point position, Point size)
        {
            base.SetSizeAndPosition(canvas, position, size);

            Point keySize = new Point((int)(Size.X * sizeSplitKey), Size.Y);
            Point valueSize = new Point((int)(Size.X * sizeSplitValue), Size.Y);
            keyText.SetSizeAndPosition(canvas, Point.Zero, keySize);
            valueText.SetSizeAndPosition(canvas, Point.Zero + new Point(keySize.X, 0), valueSize);

            if (keyText.Size.Y < Size.Y)
                keyText.Y += (Size.Y - keyText.Size.Y) / 2;
            if (valueText.Size.Y < Size.Y)
                valueText.Y += (Size.Y - valueText.Size.Y) / 2;
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            base.RenderAsChild(spriteBatch, parentPos);

            if (Canvas.DRAW_DEBUG)
            {
                Vector2 p = parentPos.ToVector2() + Position.ToVector2();
                spriteBatch.DrawLine(p, p + new Vector2(Size.X, 0), Color.Red);
                spriteBatch.DrawLine(p + new Vector2(Size.X, 0), p + new Vector2(Size.X, Size.Y), Color.Red);
                spriteBatch.DrawLine(p + new Vector2(Size.X, Size.Y), p + new Vector2(0, Size.Y), Color.Red);
                spriteBatch.DrawLine(p + new Vector2(0, Size.Y), p + new Vector2(0, 0), Color.Red);
            }            
        }


        public KeyValueText SetValueTextUpdate(Func<String> UpdateFunc)
        {
            valueText.SetTextUpdateFunction(UpdateFunc);
            return this;
        }
      
    }
}
