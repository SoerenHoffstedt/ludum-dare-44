﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarelyUI
{
    public class ModalWindow : Window
    {
        Canvas canvas;

        public ModalWindow(Panel contentPanel, string title, Canvas canvas) 
                    : base(contentPanel, title, canvas)
        {
            this.canvas = canvas;
        }

        public ModalWindow(string title, Canvas canvas)
                    : base(title, canvas)
        {
            this.canvas = canvas;
        }

        public override void Open()
        {
            base.Open();
            canvas.OpenModalWindow(this);
        }

        public override void Close()
        {
            base.Close();
            canvas.CloseModalWindow(this);
        }

    }
}
