﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BarelyUI
{
    public class HorizontalLayout : Panel
    {

        public HorizontalLayout(Point pos, Point size) : base()
        {
            SetFixedSize(size);
            SetPosition(pos);
        }

        public HorizontalLayout() : base()
        {
           
        }    

        public override void SetSizeAndPosition(Canvas canvas, Point position, Point size)
        {
            base.SetSizeAndPosition(canvas, position, size);

            int matchParentElements = 0;
            childElements.ForEach((e) => { if (e.layoutSizeX == LayoutSize.MatchParent) matchParentElements++; });
            Debug.WriteLine($"match parent childs: {matchParentElements}");

            int xToFill = Size.X - WrappingMinSize.X;
            int perToFill = matchParentElements == 0 ? 0 : xToFill / matchParentElements;
            int restToFill = matchParentElements == 0 ? 0 : xToFill % matchParentElements;

            Point p = Padding;
            for (int i = 0; i < childElements.Count; i++)
            {
                UIElement e = childElements[i];
                if(overwriteChildLayout)
                    e.layoutSizeY = childLayoutOverwrite;
                size = Size - new Point(p.X, Padding.Y * 2);

                if (hasScrollbar)
                    size.Y -= Scrollbar.SIZE + Padding.Y;

                if(e.layoutSizeX == LayoutSize.MatchParent)
                {
                    size.X = perToFill + e.MinSize.Y;
                    if(restToFill > 0)
                    {
                        size.Y += 1;
                        restToFill--;
                    }
                }

                e.SetSizeAndPosition(canvas, p, size);

                if(e.Size.X < childMinSize.X)
                {                    
                    e.Size = new Point(childMinSize.X, e.Size.Y);
                }
                if(e.Size.Y < childMinSize.Y)
                {
                    e.Size = new Point(e.Size.X, childMinSize.Y);
                }

                if(childLayoutOverwrite != LayoutSize.MatchParent)
                {
                    if (childAllignY == AnchorY.Top)
                        e.ChangeYPosition(Padding.Y);
                    else if (childAllignY == AnchorY.Middle)
                        e.ChangeYPosition((Size.Y - e.Size.Y) / 2);
                    else if (childAllignY == AnchorY.Bottom)
                        e.ChangeYPosition(Size.Y - Padding.Y - e.Size.Y);
                }

                p.X += Margin;
                p.X += e.Size.X;
            }
            p.X -= Margin;
            p.X += Padding.X;

            if(p.X > Size.Y && layoutSizeX == LayoutSize.WrapContent)
            {
                Size = new Point(p.X + Padding.X, Size.Y);
            }

            if(p.X < Size.X && childAllignX != AnchorX.Left)
            {
                int move = 0;
                if(childAllignX == AnchorX.Middle)
                {
                    move = (Size.X - p.X) / 2;
                }
                else if(childAllignX == AnchorX.Right)
                {
                    move = Size.X - p.X;
                }

                Point pMove = new Point(move, 0);

                foreach (UIElement element in childElements)
                {
                    element.Position = element.Position + pMove;
                }
            }

            if (hasScrollbar)
            {
                // this wont work, because the Scrollbar is built for vertical scrolling....
                // the instantiated scrollbar has to be a horizontal one. maybe the Scrollbar can do both.
                // switching between allowing vertical and horizontal movement shouldnt be to difficult and seems cleaner than creating two scrollbar classes
                /*
                sizeDifference = new Point(p.X - (Size.X - Padding.X - Padding.X), 0);
                if (sizeDifference.X < 0)
                    sizeDifference.X = 0;
                scrollbar.SetHeights(p.X, sizeDifference.X);

                scrollbar.layoutSizeX = LayoutSize.MatchParent;
                scrollbar.layoutSizeY = LayoutSize.WrapContent;
                Point pos    = new Point(Padding.X, size.Y - Padding.Y - Scrollbar.SIZE);
                Point sbSize = new Point(Size.X - 2 * Padding.X, Scrollbar.SIZE);
                scrollbar.SetSizeAndPosition(canvas, pos, sbSize);
                */
            }

            if (layoutFill != LayoutFill.Nothing && p.X < Size.X - 2 * Padding.X)
            {
                int toFill = Size.X - Padding.X - p.X;
                int perElement;
                int rest;
                if (layoutFill == LayoutFill.StretchContent)
                {
                    perElement = toFill / childElements.Count;
                    rest = toFill % childElements.Count;
                }
                else
                {
                    perElement = toFill / (childElements.Count - 1);
                    rest = toFill % (childElements.Count - 1);
                }
                
                int toAdd = 0;
                for (int i = 0; i < childElements.Count; i++)
                {
                    UIElement e = childElements[i];
                    if (layoutFill == LayoutFill.StretchContent)
                    {
                        Point newSize = new Point(e.Size.X + perElement, e.Size.Y);
                        LayoutSize old = e.layoutSizeX;
                        e.layoutSizeX = LayoutSize.MatchParent;
                        e.SetSizeAndPosition(canvas, e.Position + new Point(toAdd, 0), newSize);
                        e.layoutSizeX = old;
                    } else
                        e.ChangeXPosition(e.Position.X + toAdd);
                    toAdd += perElement;
                    if(rest > 0)
                    {
                        toAdd++;
                        rest--;
                    }
                }

            }            

        }

        public override Point CalculateMinSize(Canvas canvas)
        {
            Point min = new Point(0, 0);
            foreach (UIElement e in childElements)
            {
                Point eMin = e.CalculateMinSize(canvas);
                if (eMin.Y > min.Y)
                    min.Y = eMin.Y;
                min.X += eMin.X + Margin;
            }            
            min.X -= Margin;
            min += Padding + Padding;

            WrappingMinSize = min;

            if (layoutSizeX == LayoutSize.FixedSize && min.X < Size.X)
                min.X = Size.X;
            if (layoutSizeY == LayoutSize.FixedSize && min.Y < Size.Y)
                min.Y = Size.Y;

            if (layoutSizeX == LayoutSize.MatchParent)
            {
                if (Size.X != 0)
                    min.X = Size.X;
                else
                    min.X = 20;
            }

            if (layoutSizeY == LayoutSize.MatchParent)
            {
                if (Size.Y != 0)
                    min.Y = Size.Y;
                else
                    min.Y = 20;
            }

            MinSize = min;
            return min;
        }
    
    }
}
