﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace BarelyUI
{
    public class Space : UIElement
    {

        private int spaceSize;

        public Space(int size)
        {
            spaceSize = size;
        }

        public override Point CalculateMinSize(Canvas canvas)
        {
            MinSize = new Point(spaceSize, spaceSize);
            return MinSize;
        }
    }
}
