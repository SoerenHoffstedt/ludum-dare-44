﻿using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace BarelyUI.Styles
{
    public static class Style
    {
        private static Dictionary<string, StyleSheet>   allStyles;
        private static Stack<StyleSheet>                activeStyles;

        public static Dictionary<string, Sprite>        sprites;
        public static Dictionary<string, Color>         colors;
        public static Dictionary<string, SpriteFont>    fonts;

        public static void InitializeStyle(string file, ContentManager Content)
        {
            XmlDocument styleDef = new XmlDocument();
            styleDef.Load(file);

            allStyles       = new Dictionary<string, StyleSheet>();
            activeStyles    = new Stack<StyleSheet>();
            sprites         = new Dictionary<string, Sprite>();
            colors          = new Dictionary<string, Color>();
            fonts           = new Dictionary<string, SpriteFont>();

            LoadSprites(styleDef.SelectSingleNode("styles/sprites"), Content);
            LoadColors(styleDef.SelectSingleNode("styles/colors"));
            LoadFonts(styleDef.SelectSingleNode("styles/fonts"), Content);

            LoadStyles(styleDef);
        }
        
        public static void PushStyle(string styleId)
        {
            Debug.Assert(activeStyles.Count > 0);
            StyleSheet newStyle = allStyles[styleId];
            newStyle.CurrentParentStyle = activeStyles.Peek();        
            activeStyles.Push(newStyle);
        }

        /// <summary></summary>
        /// <param name="expectedName">the name you expect to pop. If name is different from active layout, exception will be thrown. Can be null to not check.</param>
        public static void PopStyle(string expectedName = null)
        {
            Debug.Assert(activeStyles.Count > 0);
            if (activeStyles.Count == 1)
            {
                throw new StyleException("You can not pop the standard style and currently no other style was popped onto the stack.");
            }

            StyleSheet old = activeStyles.Pop();
            if (expectedName != null && old.id != expectedName)
            {
                throw new StyleException("The active Style does not have the expected name. Push, Pop order might be confused.");
            }
            old.CurrentParentStyle = null;

            Debug.Assert(activeStyles.Count > 0);        
        }

        public static StyleSheet GetActiveStyle()
        {
            return activeStyles.Peek();
        }

        #region Private Methods

        private static void LoadSprites(XmlNode spritesNode, ContentManager Content)
        {
            foreach (XmlNode n in spritesNode.SelectNodes("sprite"))
            {
                string id = n.Attributes["id"].Value;
                sprites.Add(id, Sprite.Parse(n, Content));               
            }
        }

        private static void LoadColors(XmlNode colorsNode)
        {
            foreach (XmlNode n in colorsNode)
            {
                string id = n.Attributes["id"].Value;
                int r = int.Parse(n.Attributes["r"].Value);
                int g = int.Parse(n.Attributes["g"].Value);
                int b = int.Parse(n.Attributes["b"].Value);
                colors.Add(id, new Color(r, g, b));
            }
        }

        private static void LoadFonts(XmlNode fontsNode, ContentManager Content)
        {
            foreach (XmlNode n in fontsNode)
            {
                fonts.Add(n.Attributes["id"].Value, Content.Load<SpriteFont>(n.Attributes["name"].Value));
            }
        }

        private static void LoadStyles(XmlNode styles)
        {
            string stdName = "standard";
            StyleSheet standard = StyleSheet.LoadFromXml(styles.SelectSingleNode("styles/standard"), sprites, colors, fonts, stdName);
            allStyles.Add(stdName, standard);
            activeStyles.Push(standard);

            foreach (XmlNode n in styles.SelectNodes("styles/style"))
            {
                string id = n.Attributes["id"].Value;
                allStyles.Add(id, StyleSheet.LoadFromXml(n, sprites, colors, fonts, id));
            }
        }

        #endregion

    }
}
