﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Barely.Util;
using BarelyUI.Styles;
using Microsoft.Xna.Framework;
using static BarelyUI.Button;

namespace BarelyUI
{
    public class Slider : UIElement
    {
        public Action<int> UpdateValueFunction;

        private SliderHandle handle;

        private int minValue;
        private int maxValue;
        private int stepSize;
        private int startValue;
        private int currValue;

        private int edgeSpace = 6;

        public Slider(Action<int> UpdateValueFunction, int minValue, int maxValue, int stepSize, int startValue)
        {
            this.UpdateValueFunction = UpdateValueFunction;
            var style = Style.GetActiveStyle();

            this.minValue = minValue;
            this.maxValue = maxValue;
            this.stepSize = stepSize;
            this.startValue = startValue;
            this.currValue = startValue;

            layoutSizeX = LayoutSize.MatchParent;
            layoutSizeY = LayoutSize.WrapContent;
            Padding = new Point(0, 0);

            this.sprite = style.GetSliderBarSprite();

            handle = new SliderHandle(this, edgeSpace);
            AddChild(handle);
        }

        public override void SetSizeAndPosition(Canvas canvas, Point position, Point size)
        {
            layoutSizeX = LayoutSize.MatchParent;
            base.SetSizeAndPosition(canvas, position, size);            
            //Size = new Point(size.X, Size.Y);
        }

        public override Point CalculateMinSize(Canvas canvas)
        {
            MinSize = new Point(200, 20);
            return MinSize;
        }

        private float CalculateNewValue(float currPos)
        {
            currValue = minValue +  (int)Math.Round((maxValue - minValue) * currPos);
            //snap value

            int modulo = (currValue - minValue) % stepSize;
            if (modulo != 0)
            {
                if (modulo < stepSize / 2)
                    currValue -= modulo;
                else
                    currValue += stepSize - modulo;
            }

            UpdateValueFunction(currValue);
            //tell handle to snap to position:            
            return (float)(currValue - minValue) / (maxValue - minValue);
        }

        public override void LeftMouseClick(Point localMousePos)
        {
            base.LeftMouseClick(localMousePos);

            float perc = (localMousePos.X - edgeSpace) / (float)(Size.X - edgeSpace - edgeSpace);
            handle.ClickOnBar(CalculateNewValue(perc));
        }

        private class SliderHandle : UIElement
        {
            private bool isDragging = false;
            private Point handleSize;
            private Slider sliderParent;

            private int minPos, maxPos;

            private int internalXPosition;

            private Point mouseDownPosition;

            private Color[] colors;            

            public SliderHandle(Slider parent, int edgeSpace)
            {
                minPos = edgeSpace;
                this.sliderParent = parent;
                handleSize = new Point(24, 24);

                var style = Style.GetActiveStyle();
                sprite = style.GetSliderHandleSprite();

                hasMouseDownFocus = true;

                colors = style.GetButtonColors();
                color = colors[(int)ButtonColors.Normal];

            }

            public void ClickOnBar(float snapTo)
            {
                int oldX = X;
                X = minPos + (int)Math.Round((maxPos - minPos) * snapTo);
                if(X != oldX)
                    Sounds.Play("sliderNewValue");
            }

            private void ReportAndSnapPosition()
            {
                float pos = (float)(internalXPosition - minPos) / (maxPos - minPos);
                float snapTo = sliderParent.CalculateNewValue(pos);
                int oldX = X;
                X = minPos + (int)Math.Round((maxPos - minPos) * snapTo);
                if (X != oldX)
                    Sounds.Play("sliderNewValue");
            }

            public override Point CalculateMinSize(Canvas canvas)
            {
                MinSize = handleSize;
                return MinSize;
            }

            public override void SetSizeAndPosition(Canvas canvas, Point position, Point size)
            {
                Size = handleSize;
                base.SetSizeAndPosition(canvas, position, size);
                Y -= 2;
                maxPos = parent.Size.X - this.Size.X - minPos;

                float startPercent = (sliderParent.startValue - sliderParent.minValue) / (float)(sliderParent.maxValue - sliderParent.minValue);
                int startPos = minPos + (int)Math.Round((maxPos - minPos) * startPercent);
                internalXPosition = X = startPos;
                
            }

            public override void LeftMouseDown(Point localMousePos)
            {
                base.LeftMouseDown(localMousePos);                
                isDragging = true;
                color = colors[(int)ButtonColors.MouseDown];
                mouseDownPosition = localMousePos - Position - scrollOffset;
            }

            public override void LeftMouseStillPressed(Point localMousePos)
            {

                localMousePos += Position + scrollOffset;

                if (isDragging)
                {                                       
                    internalXPosition = localMousePos.X - mouseDownPosition.X;
                  
                    if (internalXPosition < minPos)
                        internalXPosition = minPos;
                    if (internalXPosition > maxPos)
                        internalXPosition = maxPos;                

                    ReportAndSnapPosition();
                }
            }

            public override void LeftMouseClick(Point localMousePos)
            {
                base.LeftMouseClick(localMousePos);                
                isDragging = false;
                if(localMousePos.X < Size.X && localMousePos.Y < Size.Y && localMousePos.X >= 0 && localMousePos.Y >= 0)
                    color = colors[(int)ButtonColors.MouseOver];
                else
                    color = colors[(int)ButtonColors.Normal];
            }

            public override void MouseEnter()
            {
                base.MouseEnter();
                color = colors[(int)ButtonColors.MouseOver];
            }

            public override void MouseExit()
            {
                base.MouseExit();

                if (!isMouseDown)
                    color = colors[(int)ButtonColors.Normal];
            }

            public override void LooseMouseDownFocus()
            {
                base.LooseMouseDownFocus();
                isDragging = false;
                color = colors[(int)ButtonColors.Normal];
            }       

        }

    }

}
