﻿using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Xml;

namespace BarelyUI
{
    public class Canvas
    {
        public static bool DRAW_DEBUG = false;

        private List<UIElement> childElements;

        private UIElement mouseOverElement = null;
        private UIElement lastMouseOverElement = null;
        private UIElement mouseDownElement = null;

        private UIElement modalWindow = null;
        public Point Resolution { get; private set; }

        private bool finishCalled = false;

        public GraphicsDevice GraphicsDevice;

        public Canvas(ContentManager Content, Point resolution, GraphicsDevice GraphicsDevice)
        {
            Resolution = resolution;
            this.GraphicsDevice = GraphicsDevice;
            childElements = new List<UIElement>();        
        }  

        public void Update(float deltaTime)
        {
            if (!finishCalled)
                throw new Exception("After creating the UI you have to call FinishCreation on the Canvas.");

            foreach (Panel p in childElements)
                p.Update(deltaTime);
        }


        public bool HandleInput()
        {
            Point mousePos = Input.GetMousePosition();
            Point localMousePos = mousePos;
            bool handled = false;
            UIElement newLastMouseOver = null;
            UIElement moveToFront = null;

            /*
            foreach (UIElement objRun in UIObjectsWithMouseDownFocus)
            {
                if (objRun.isMouseOver && objRun != newLastMouseOver)
                {
                    objRun.MouseExit();
                }
                else if (objRun.isMouseDown)
                {

                    if (Input.GetLeftMousePressed())
                        objRun.LeftMousePressed();
                    else if (Input.GetLeftMouseUp())
                        objRun.LeftMouseClick(localMousePos);

                    handled = true;
                }
            }*/


            if (mouseDownElement != null)
            {                
                if (Input.WasAnyMouseClick())
                {
                    mouseDownElement.LooseMouseDownFocus();
                    mouseDownElement.isMouseDown = false;
                    mouseDownElement.isMouseOver = false;
                    mouseDownElement = null;
                }
                else
                {
                    UIElement parent = mouseDownElement;
                    while(parent != null)
                    {
                        localMousePos -= parent.Position;
                        localMousePos -= parent.scrollOffset;
                        parent = parent.parent;
                    }
                    

                    if (Input.GetLeftMousePressed())
                        mouseDownElement.LeftMouseStillPressed(localMousePos);
                    else if (Input.GetRightMousePressed())
                        mouseDownElement.RightMouseStillPressed(localMousePos);
                    else if (Input.GetMiddleMousePressed())
                        mouseDownElement.MiddleMouseStillPressed(localMousePos);
                }                
            }


            for (int i = childElements.Count - 1; i >= 0; i--)
            {
                UIElement objRun = childElements[i];            

                if (!handled && objRun != null && objRun.isOpen && objRun.Interactable && (modalWindow == null || objRun == modalWindow) && 
                    new Rectangle(objRun.Position, objRun.Size).Contains(mousePos))                  
                {
                    UIElement obj = objRun;
                    
                    obj = objRun.FindMouseOverElement(ref localMousePos);                                        

                    if(mouseDownElement != null && obj != mouseDownElement)
                    {
                        break;   
                    }

                    /*if (focusedObject != null && obj != focusedObject && Input.WasAnyMouseClick())
                    {
                        focusedObject.OnLooseFocus();
                    }
                    */

                    if (Input.GetLeftMouseUp())
                    {
                        obj.LeftMouseClick(localMousePos);
                        mouseDownElement = null;
                    }
                    else if (Input.GetLeftMouseDown())
                    {
                        obj.LeftMouseDown(localMousePos);
                        mouseDownElement = obj;
                        moveToFront = objRun;
                    }                    
                    else if(Input.GetLeftMousePressed())
                    {
                        obj.LeftMouseStillPressed(localMousePos);
                    }
                    else if (Input.GetRightMouseUp())
                    {
                        obj.RightMouseClick(localMousePos);
                        mouseDownElement = null;
                    }
                    else if (Input.GetRightMouseDown())
                    {
                        obj.RightMouseDown(localMousePos);
                        mouseDownElement = obj; moveToFront = objRun;
                    }
                    else if (Input.GetRightMousePressed())
                    {
                        obj.RightMouseStillPressed(localMousePos);
                    }
                    else if (Input.GetMiddleMouseUp())
                    {
                        obj.MiddleMouseClick(localMousePos);
                        mouseDownElement = null;
                    }
                    else if (Input.GetMiddleMouseDown())
                    {
                        obj.MiddleMouseDown(localMousePos);
                        mouseDownElement = obj;
                        moveToFront = objRun;
                    }                   
                    else if (Input.GetMouseWheelDelta() < 0)
                    {
                        obj.ScrollWheelDown(Input.GetMouseWheelDelta());
                    }
                    else if (Input.GetMouseWheelDelta() > 0)
                    {
                        obj.ScrollWheelUp(Input.GetMouseWheelDelta());
                    }
                    else if (!obj.isMouseOver)
                    {
                        obj.MouseEnter();
                    }
                    else
                    {
                        obj.MouseStillOver();
                    }

                    newLastMouseOver = obj;
                    handled = true;
                }
                else if (objRun.isMouseOver)
                {
                    objRun.MouseExit();
                }
                else if (objRun.isMouseDown)
                {
                    if (Input.GetLeftMousePressed())
                        objRun.LeftMouseStillPressed(localMousePos);
                    else if (Input.GetLeftMouseUp())
                        objRun.LeftMouseClick(localMousePos);
                }
            }
            

            if (lastMouseOverElement != null && lastMouseOverElement != newLastMouseOver)
            {
                if (lastMouseOverElement.isMouseOver)
                {
                    lastMouseOverElement.MouseExit();
                }
            }

            if (!handled && modalWindow != null && (Input.GetLeftMouseUp() || Input.GetRightMouseUp() || Input.GetMiddleMouseUp()))
            {
                handled = true;
                Sounds.Play("clickOutsideModalWindow");
            }

            if(moveToFront != null)
            {
                childElements.Remove(moveToFront);
                childElements.Add(moveToFront);
            }

            lastMouseOverElement = newLastMouseOver;

            return handled;
        }      

        public void Render(SpriteBatch spriteBatch)
        {
            if (!finishCalled)            
                throw new Exception("After creating the UI you have to call FinishCreation on the Canvas.");
            

            foreach (UIElement element in childElements)
            {
                if(element.isOpen)
                    element.Render(spriteBatch);
            }
        }

        public void AddChild(UIElement e)
        {
            childElements.Add(e);
        }

        public void AddChild(params UIElement[] elements)
        {
            foreach(UIElement e in elements)
            {
                childElements.Add(e);
            }
        }        

        public void FinishCreation()
        {
            finishCalled = true;

            for (int i = 0; i < childElements.Count; i++)
            {
                childElements[i].SetParentAndCanvas(this, null);
            }

            for (int i = 0; i < childElements.Count; i++)                
            {
                childElements[i].SetSizeAndPosition(this, Point.Zero, Point.Zero);
            }
        }

        public void OpenModalWindow(ModalWindow mw)
        {
            modalWindow = mw;
        }

        public void CloseModalWindow(ModalWindow mw)
        {
            modalWindow = null;
        }       

    }
}
