﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using BarelyUI.Styles;
using BarelyUI.Layouts;

namespace BarelyUI
{
    public abstract class Panel : UIElement
    {
        public AnchorX anchorX = AnchorX.Left;
        public AnchorY anchorY = AnchorY.Top;

        public LayoutOverflow layoutOverflow = LayoutOverflow.Overflow; //LayoutOverflow.ScrollBar;
        public LayoutFill     layoutFill        = LayoutFill.Nothing;

        public bool         overwriteChildLayout = true;
        public LayoutSize   childLayoutOverwrite;
        public AnchorX      childAllignX;
        public AnchorY      childAllignY;

        public int Margin { get; set; }
        protected Point childMinSize;

        protected Point sizeDifference;

        protected bool hasScrollbar     = false;

        public Action OnOpen;
        public Action OnClose;

        protected Scrollbar scrollbar;
        protected GraphicsDevice GraphicsDevice;

        public Panel()
        {
            var style       = Style.GetActiveStyle();
            if(style.GetPanelHasSprite())
                sprite      = style.GetPanelSprite();
            var layout      = Layout.GetActiveLayout();
            Padding         = layout.GetPanelPadding();
            Margin          = layout.GetPanelMargin();
            anchorX         = layout.GetPanelAnchorX();
            anchorY         = layout.GetPanelAnchorY();
            layoutOverflow  = layout.GetPanelLayoutOverflow();
            layoutFill      = layout.GetPanelLayoutFill();

            overwriteChildLayout = layout.GetPanelHasChildLayoutOverwrite();
            if (overwriteChildLayout)
                childLayoutOverwrite = layout.GetPanelChildLayoutOverwrite();

            childAllignX = layout.GetPanelChildAllignX();
            childAllignY = layout.GetPanelChildAllignY();
        }

        public Panel AddScrollbar()
        {
            hasScrollbar = true;
            scrollbar = new Scrollbar();            
            return this;
        }

        internal override void SetParentAndCanvas(Canvas canvas, UIElement parent)
        {
            base.SetParentAndCanvas(canvas, parent);
            if (scrollbar != null)
                scrollbar.SetParentAndCanvas(canvas, this);
        }

        public Panel SetChildMinSize(int x, int y)
        {            
            return SetChildMinSize(new Point(x,y));
        }

        public Panel SetChildMinSize(Point p)
        {
            if (p.X < Size.X || p.Y < Size.Y)
                throw new ArgumentException("ChildMinSize cannot be smaller than Size of Panel.");
            childMinSize = p;
            return this;
        }        

        public Panel SetMargin(int m)
        {
            Margin = m;
            return this;
        }
       
        public Panel SetAnchor(AnchorX x, AnchorY y)
        {
            anchorX = x;
            anchorY = y;
            return this;
        }                

        public Panel SetPosition(int x, int y)
        {            
            return SetPosition(new Point(x,y));
        }

        public Panel SetPosition(Point p)
        {
            Position = p;
            return this;
        }

        public override void SetSizeAndPosition(Canvas canvas, Point position, Point parentGivenSize)
        {
            GraphicsDevice = canvas.GraphicsDevice;
            Point min = CalculateMinSize(canvas);

            Point p;
            if (position != Point.Zero)
                p = position;
            else
                p = Position;                                  

            Point res = canvas.Resolution;

            if (layoutSizeX == LayoutSize.MatchParent)
                Size = new Point(parentGivenSize.X, Size.Y);
            else if (layoutSizeX == LayoutSize.WrapContent)
            {                             
                Size = new Point(min.X, Size.Y);
            }

            if (layoutSizeY == LayoutSize.MatchParent)
                Size = new Point(Size.X, parentGivenSize.Y);
            else if (layoutSizeY == LayoutSize.WrapContent)
            {                                
                Size = new Point(Size.X, min.Y);
            }

            switch (anchorX)
            {
                case AnchorX.Left:
                    break;
                case AnchorX.Middle:
                    p.X = res.X / 2 - Size.X / 2 + Position.X;
                    break;
                case AnchorX.Right:
                    p.X = res.X - Size.X - Position.X;
                    break;
            }

            switch (anchorY)
            {
                case AnchorY.Top:
                    break;
                case AnchorY.Middle:
                    p.Y = res.Y / 2 - Size.Y / 2 + Position.Y;
                    break;
                case AnchorY.Bottom:
                    p.Y = res.Y - Size.Y - Position.Y;
                    break;
            }
            Position = p;           

        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            if(sprite != null)
            {
                sprite.Render(spriteBatch, new Rectangle(parentPos + Position, Size), color);
            }

            if (!isOpen)
                return;

            if (Canvas.DRAW_DEBUG)
            {
                Color c = Color.Red;
                Vector2 p = parentPos.ToVector2() + Position.ToVector2();
                spriteBatch.DrawLine(p, p + new Vector2(Size.X, 0), c);
                spriteBatch.DrawLine(p + new Vector2(Size.X, 0), p + new Vector2(Size.X, Size.Y), c);
                spriteBatch.DrawLine(p + new Vector2(Size.X, Size.Y), p + new Vector2(0, Size.Y), c);
                spriteBatch.DrawLine(p + new Vector2(0, Size.Y), p + new Vector2(0, 0), c);
            }                        

            Rectangle oldScissor = Rectangle.Empty;
            if (hasScrollbar)
            {                
                scrollbar.RenderAsChild(spriteBatch, parentPos + Position);
                oldScissor = GraphicsDevice.ScissorRectangle;
                GraphicsDevice.ScissorRectangle = new Rectangle(parentPos + Position + Padding, Size - Padding - Padding);
                float scrollVal = scrollbar.GetScrollValue();
                scrollOffset = (-scrollVal * sizeDifference.ToVector2()).ToPoint();
            }            

            foreach (UIElement e in childElements)
            {
                if(e != scrollbar)
                    e.RenderAsChild(spriteBatch, parentPos + Position + scrollOffset);
            }

            if (hasScrollbar)
                GraphicsDevice.ScissorRectangle = oldScissor;
        }

        public override void Open()
        {
            base.Open();
            if (OnOpen != null)
                OnOpen();
        }

        public override void Close()
        {
            base.Close();
            if (OnClose != null)
                OnClose();
        }

    }

    public enum LayoutFill
    {
        Nothing,
        StretchContent,
        StretchMargin
    }

    public enum LayoutOverflow
    {
        Scrollbar,
        Overflow,
        Truncate,
        ThrowException
    }

}
