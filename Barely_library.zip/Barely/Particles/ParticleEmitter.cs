﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Particles
{
    public class ParticleEmitter
    {


        bool isActive = true;
                
        Vector2     position;

        Vector2     direction;
        float       directionOffset;

        float       speed;
        float       speedOffset;

        float       duration;
        float       durationOffset;

        int         spawnsPerSecond;

        Particle[]  particles;


        public ParticleEmitter()
        {

            int max = (int)Math.Ceiling(spawnsPerSecond * (duration + durationOffset));
            particles = new Particle[max];
        }


        public void Update(double deltaTime)
        {

        }

        public void Render(SpriteBatch spriteBatch)
        {

        }

    }
}
