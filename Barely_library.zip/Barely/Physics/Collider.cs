﻿using Barely.Physics.Geometry;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics
{
    class Collider
    {

        private Shape2D collisionShape;

        public bool isTrigger = false;
        
        public Collider()
        {

        }

    }
}
