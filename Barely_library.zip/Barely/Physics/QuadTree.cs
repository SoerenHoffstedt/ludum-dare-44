﻿using Barely.Physics.Geometry;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics
{
    /*
     * Quad Tree. A element spanning multiple max depth nodes will be in every node it overlaps. 
     */
    public class QuadTree<T>
    {

        int maxDepth;
        int maxObjectsPerNode;

        QuadTreeNode<T> root;

        public QuadTree(Rect sceneSize, int maxDepth, int maxObjectsPerNode)
        {
            this.maxDepth = maxDepth;
            this.maxObjectsPerNode = maxObjectsPerNode;
            root = new QuadTreeNode<T>(sceneSize, 0, maxDepth, maxObjectsPerNode);
        }

        /// <summary>
        /// Standard Constructor with maxDepth = 5 and maxObjectsPerNode = 15
        /// </summary>
        public QuadTree()
        {
            maxDepth = 5;
            maxObjectsPerNode = 15;
        }

        public void Insert(T element, Rect bounds)
        {
            root.Insert(new QuadTreeElement<T>(element, bounds));
        }

        public void Remove(T element, Rect bounds)
        {
            //root.Remove()
        }

    }


    public class QuadTreeElement<T>
    {
        public T data;        
        public Rect bounds;

        /// <summary> if this element was already checked for collision in another node </summary>
        public bool flag;

        public QuadTreeElement(T d, Rect b)
        {
            data = d;
            bounds = b;
            flag = false;
        }

    }

    public class QuadTreeNode<T>
    {
        protected List<QuadTreeNode<T>> children;
        protected List<QuadTreeElement<T>> contents;
        protected int currentDepth;
        protected int maxDepth;
        protected Rect nodeBounds;
        protected int maxObjectsPerNode;

        public QuadTreeNode(Rect bounds, int currentDepth, int maxDepth, int maxObjectsPerNode)
        {
            nodeBounds = bounds;
            currentDepth = 0;
            children = new List<QuadTreeNode<T>>(maxObjectsPerNode);
            contents = new List<QuadTreeElement<T>>();
            this.currentDepth = currentDepth;
            this.maxObjectsPerNode = maxObjectsPerNode;
            this.maxDepth = maxDepth;
        }

        public bool IsLeaf()
        {
            return children.Count == 0;
        }

        public int NumObjects()
        {
            Reset();
            int count = contents.Count;
            for (int i = 0, size = contents.Count; i < size; i++)
            {
                contents[i].flag = true;
            }
            Queue<QuadTreeNode<T>> process = new Queue<QuadTreeNode<T>>(1 + children.Count);
            process.Enqueue(this);
            while(process.Count > 0)
            {
                QuadTreeNode<T> processing = process.Dequeue();
                if (!processing.IsLeaf())
                {
                    for (int i = 0, size = processing.children.Count; i < size; i++)
                    {
                        process.Enqueue(processing.children[i]);
                    }
                } else
                {
                    for (int i = 0, size = processing.children.Count; i < size; i++)
                    {
                        if (!processing.contents[i].flag)
                        {
                            count += 1;
                            processing.contents[i].flag = true;
                        }
                    }
                }
            }
            Reset();
            return count;
        }

        public void Insert(QuadTreeElement<T> data)
        {
            if (!nodeBounds.Collides(data.bounds))
                return;
            if (IsLeaf() && contents.Count + 1 > maxObjectsPerNode)
                Split(); //Try splitting
            if (IsLeaf())
            {
                contents.Add(data);
            } else
            {
                //try insert into all child nodes because elements is saved in every overlapping node
                foreach (QuadTreeNode<T> child in children)
                {
                    child.Insert(data);
                }
            }
        }

        public void Remove(QuadTreeElement<T> data)
        {
            if (IsLeaf())
            {
                contents.Remove(data);
            } else
            {
                foreach(QuadTreeNode<T> child in children)
                {
                    child.Remove(data);
                }
            }
            Shake();
        }

        public void Update(QuadTreeElement<T> data)
        {
            Remove(data);
            Insert(data);
        }

        public void Shake()
        {
            if (!IsLeaf())
            {
                int numObjects = NumObjects();
                if (numObjects == 0)
                {
                    children.Clear();
                }
                else if (numObjects < maxObjectsPerNode)
                {
                    Queue<QuadTreeNode<T>> process = new Queue<QuadTreeNode<T>>();
                    process.Enqueue(this);
                    while(process.Count > 0)
                    {
                        QuadTreeNode<T> processing = process.Dequeue();
                        if (!processing.IsLeaf())
                        {
                            for (int i = 0; i < processing.children.Count; i++)
                            {
                                process.Enqueue(processing.children[i]);
                            }
                        } else
                        {
                            contents.AddRange(processing.contents);
                        }
                    }
                    children.Clear();
                }
            }
        }

        public void Split()
        {
            if (currentDepth + 1 >= maxDepth)
                return;
            Vector2 min = nodeBounds.Min;
            Vector2 max = nodeBounds.Max;
            Vector2 center = min + ((max - min) * 0.5f);
            Rect[] childAreas =
            {
                Rect.FromMinMax(min.X, min.Y, center.X, center.Y),
                Rect.FromMinMax(center.X, min.Y, max.X, center.Y),
                Rect.FromMinMax(center.X, center.Y, max.X, max.Y),
                Rect.FromMinMax(min.X, center.Y, center.X, max.Y)
            };

            //this is very unclear and different in the book. fuck the book, it sucks.
            for (int i = 0; i < 4; i++)
            {
                children.Add(new QuadTreeNode<T>(childAreas[i], currentDepth + 1, maxDepth, maxObjectsPerNode));
                foreach (var content in contents)
                {
                    children[i].Insert(content);
                }
            }
            contents.Clear();
        }

        public void Reset()
        {
            if (IsLeaf())
            {
                for (int i = 0; i < contents.Count; i++)
                {
                    contents[i].flag = false;
                }
            } else
            {
                for (int i = 0; i < children.Count; i++)
                {
                    children[i].Reset();
                }
            }
        }

        public List<QuadTreeElement<T>> Query(Rect area)
        {
            if(!area.Collides(nodeBounds))
                return new List<QuadTreeElement<T>>(0);

            List<QuadTreeElement<T>> result = new List<QuadTreeElement<T>>(32);
            if (IsLeaf())
            {
                foreach(QuadTreeElement<T> content in contents)
                {
                    if (area.Collides(content.bounds))
                        result.Add(content);
                }
            }
            else
            {
                foreach(QuadTreeNode<T> child in children)
                {
                    var recursiveList = child.Query(area);
                    result.AddRange(recursiveList);
                }
            }

            return result;
        }

    }

}
