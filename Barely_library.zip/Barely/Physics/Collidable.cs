﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics
{
    interface Collidable
    {

        Collider Collider { get; set; }

        void OnCollision(Collidable other, CollisionData data);

        void OnTrigger(Collidable other, CollisionData data);

        Vector2 GetPosition();

    }
}
