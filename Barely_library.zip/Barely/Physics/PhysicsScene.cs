﻿using Barely.Physics.Geometry;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics
{
    public class PhysicsScene
    {

        protected QuadTree<Shape2D> quadTree;

        public PhysicsScene(Vector2 sceneSize)
        {
            quadTree = new QuadTree<Shape2D>(new Rect(0, 0, sceneSize.X, sceneSize.Y), 6, 15);
        }

    }
}
