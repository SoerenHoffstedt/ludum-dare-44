﻿using Barely.Physics.Overlap;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics.Geometry
{
    public struct Rect : Shape2D
    {
        public Vector2 origin;
        public Vector2 size;

        public Rect(float x, float y, float w, float h)
        {
            origin  = new Vector2(x, y);
            size    = new Vector2(w, h);
        }

        public Rect(Vector2 origin, Vector2 size)
        {
            this.origin = origin;
            this.size = size;
        }

        public static Rect FromMinMax(Vector2 min, Vector2 max)
        {
            return new Rect(min, max - min);
        }

        public static Rect FromMinMax(float x, float y, float xx, float yy)
        {
            return FromMinMax(new Vector2(x, y), new Vector2(xx, yy));
        }

        public Vector2 Min
        {
            get
            {
                Vector2 p1 = origin;
                Vector2 p2 = origin + size;
                return new Vector2(p1.X < p2.X ? p1.X : p2.X, p1.Y < p2.Y ? p1.Y : p2.Y);
            }
        }
        public Vector2 Max
        {
            get
            {
                Vector2 p1 = origin;
                Vector2 p2 = origin + size;
                return new Vector2(p1.X > p2.X ? p1.X : p2.X, p1.Y > p2.Y ? p1.Y : p2.Y);
            }
        }

        public Interval2D GetInterval(Vector2 axis)
        {
            Interval2D result;
            Vector2 min = Min;
            Vector2 max = Max;
            Vector2[] verts = { new Vector2(min.X, min.Y), new Vector2(min.X, max.Y), new Vector2(max.X, max.Y), new Vector2(max.X, min.Y) };
            result.min = result.max = Vector2.Dot(axis, verts[0]);
            for(int i = 1; i < 4; i++)
            {
                float projection = Vector2.Dot(axis, verts[i]);
                if (projection < result.min)
                    result.min = projection;
                if (projection > result.max)
                    result.max = projection;
            }
            return result;
        }


        public static Rect CreateContainingRect(List<Vector2> points)
        {
            Vector2 min = points[0];
            Vector2 max = points[0];

            for (int i = 1; i < points.Count; i++)
            {
                min.X = points[i].X < min.X ? points[i].X : min.X;
                min.Y = points[i].Y < min.Y ? points[i].Y : min.Y;
                max.X = points[i].X > min.X ? points[i].X : min.X;
                max.Y = points[i].Y > min.Y ? points[i].Y : min.Y;
            }

            return Rect.FromMinMax(min, max);
        }

        public bool Collides(Circle c)
        {
            return Collision.Collides(c, this);
        }

        public bool Collides(Rect r)
        {
            return Collision.Collides(r, this);
        }

        public bool Collides(OrientedRect o)
        {
            return Collision.Collides(o, this);
        }

        public bool Collides(BoundingShape bs)
        {
            return Collision.Collides(bs, this);
        }
    }
}
