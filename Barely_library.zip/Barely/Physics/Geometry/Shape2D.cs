﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Physics.Geometry
{
    public interface Shape2D
    {

        bool Collides(Circle c);
        bool Collides(Rect r);
        bool Collides(OrientedRect o);
        bool Collides(BoundingShape bs);

    }
}
