﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Barely.SceneManagement
{
    public class BarelyGame : Game
    {
        protected SpriteBatch spriteBatch;
        protected List<BarelyScene> gameScenes;
        protected BarelyScene currentScene;

        public BarelyGame() {
            gameScenes = new List<BarelyScene>();
        }

        protected override void Initialize()
        {
            base.Initialize();
            spriteBatch = new SpriteBatch(GraphicsDevice);

        }

        protected override void OnExiting(object sender, EventArgs args)
        {
            base.OnExiting(sender, args);
        }

        protected override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            base.Draw(gameTime);
        }


        public void TransitionScene<T>(T newScene) where T : BarelyScene
        {
            
        }

    }
}
