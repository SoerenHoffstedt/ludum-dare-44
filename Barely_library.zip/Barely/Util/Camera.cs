﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace Barely.Util {

    public class Camera {

        public static Camera main;

        public Vector2 position;     
        public float posX { get {return position.X; } set { position.X = value; UpdateTransform(); } }
        public float posY { get { return position.Y; } set { position.Y = value; UpdateTransform(); } }

        bool restrictMovement = false;
        Vector2 minPosition;
        Vector2 maxPosition;

        public float rotation = 0f;
        public float zoom = 2f;
        private Rectangle bounds;

        Matrix transform;
        public Matrix uiTransform;

        //Shake Parameter:
        Random random = new Random();
        bool isShaking = false;
        double angle;
        double strength;
        double speed;
        double duration;
        double noisePercent;
        double dampingPercent;
        double rotationPercent;

        //Shake execution variables:
        public Vector2 shakeOffset;
        Vector2 previousWaypoint = Vector2.Zero;
        Vector2 currentWaypoint = Vector2.Zero;
        double radians = 0f;
        double moveDistance = 0f;
        double movePercent = 0f;
        double completionPercent = 0f;


        public Camera(Viewport viewport, float zoom, float uiZoom) {
            bounds = viewport.Bounds;
            position = new Vector2(viewport.Width / (2*zoom), viewport.Height / (2*zoom));
            this.zoom = zoom;
            main = this;
            UpdateTransform();

            uiTransform = Matrix.CreateTranslation(new Vector3(-position.X * 2, -position.Y * 2, 0)) *
                Matrix.CreateRotationZ(rotation) *
                Matrix.CreateScale(new Vector3(1, 1, 1)) *
                Matrix.CreateTranslation(new Vector3(bounds.Width / (int)zoom, bounds.Height / (int)zoom, 0));
        }

        public void SetPosition(Point playerPos) {
            position = playerPos.ToVector2();
        }

        public void SetMinMaxPosition(Vector2 minPosition, Vector2 maxPosition)
        {
            restrictMovement = true;
            this.minPosition = minPosition;
            this.maxPosition = maxPosition;
        }

        public void DeactiveMinMaxPosition()
        {
            restrictMovement = false;
        }

        public Matrix Transform {
            get { return transform; }
        }

        void UpdateTransform() {
            transform = Matrix.CreateTranslation(new Vector3(-position.X + shakeOffset.X, -position.Y + shakeOffset.Y, 0)) *
                Matrix.CreateRotationZ(rotation) *
                Matrix.CreateScale(new Vector3(zoom, zoom, 1)) *
                Matrix.CreateTranslation(new Vector3(bounds.Width * 0.5f, bounds.Height * 0.5f, 0));
        }

        public void Update(double deltaTime, Vector2 movement) {
            position += movement;

            if (restrictMovement)
            {
                if (position.X < minPosition.X)
                    position.X = minPosition.X;
                else if (position.X > maxPosition.X)
                    position.X = maxPosition.X;

                if (position.Y < minPosition.Y)
                    position.Y = minPosition.Y;
                else if (position.Y > maxPosition.Y)
                    position.Y = maxPosition.Y;
            }

            UpdateTransform();

            if(isShaking)
            {
                completionPercent       += deltaTime / duration; 
                movePercent             += deltaTime / moveDistance * speed;
                shakeOffset             = Vector2.Lerp(previousWaypoint, currentWaypoint, (float)movePercent);

                if(completionPercent >= 1d)
                {
                    isShaking = false;
                    if(Vector2.Distance(shakeOffset, Vector2.Zero) > 2f)
                        shakeOffset = Vector2.Zero;
                    else
                        shakeOffset = Vector2.Zero;
                } 
                else if(movePercent >= 1d)
                {
                    double dampingFactor = DampingCurve(completionPercent, dampingPercent);
                    double noiseAngle   = (random.NextDouble() - 0.5) * Math.PI;
                    radians             += Math.PI + noiseAngle * noisePercent;
                    previousWaypoint    = currentWaypoint;
                    currentWaypoint     = new Vector2((float)Math.Cos(radians), (float)Math.Sin(radians)) * (float)strength * (float)dampingFactor;
                    moveDistance        = Vector2.Distance(previousWaypoint, currentWaypoint);
                    movePercent         = 0.0;
                    Debug.WriteLine($"Completion: {completionPercent}; Damping: {dampingFactor}");
                }
            }
        }

        double DampingCurve(double x, double dampingPercent)
        {
            if(dampingPercent > 0.0)
            {
                x = 1.0 - x;
                if(x < 0.5f)
                    x = 0.5f;
                return x;
            } else
                return 1.0;

            x = MathHelper.Clamp((float)x, 0f, 1f);
            double a = MathHelper.Lerp(2f, 0.25f, (float)dampingPercent);
            double b = 1.0 - Math.Pow(x, a);
            return b * b;
        }

        public void Shake(float angle, float strength, float speed, float duration, float noisePercent, float dampingPercent, float rotationPercent)
        {
            System.Diagnostics.Debug.Assert(noisePercent >= 0f && noisePercent <= 1f && dampingPercent >= 0f && dampingPercent <= 1f && rotationPercent >= 0f && rotationPercent <= 1f);

            isShaking               = true;
            this.angle              = angle;
            this.strength           = strength;
            this.speed              = speed;
            this.duration           = duration;
            this.noisePercent       = noisePercent;
            this.dampingPercent     = dampingPercent;
            this.rotationPercent    = rotationPercent;

            radians                 = MathHelper.ToRadians(angle);
            previousWaypoint        = Vector2.Zero;
            currentWaypoint         = new Vector2((float)Math.Cos(radians), (float)Math.Sin(radians)) * (float)this.strength;
            moveDistance            = Vector2.Distance(currentWaypoint, previousWaypoint);
            completionPercent       = 0.0;
            movePercent             = 0.0;
            shakeOffset             = Vector2.Zero;
        }

        public Point ToWorld(Point mousePosition) {
            return Vector2.Transform(mousePosition.ToVector2(), Matrix.Invert(Transform)).ToPoint();
        }

        public Point ToScreen(Point worldPosition) {
            return Vector2.Transform(worldPosition.ToVector2() + new Vector2(0.5f, 0.5f), Transform).ToPoint();
        }
    }
}