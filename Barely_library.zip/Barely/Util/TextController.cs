﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Xml;

namespace Barely.Util {

    public enum Language { en, de, fr, it, sp, ru }

    public static class Texts {

        public static Language currentLanguage { private set; get; }
                

        private static Dictionary<string, string> text;



        public static void SetTextFile(XmlDocument textFile) {
            text = new Dictionary<string, string>();
            foreach(XmlNode node in textFile.SelectNodes("language/string"))
            {
                text.Add(node.Attributes["id"].Value, node.InnerText);
            }
        }

        public static string Get(string id) {
            if(text.ContainsKey(id))
                return text[id];
            else
            {
                //Debug.WriteLine($"MISSING TEXT: for id: {id} not found for language {currentLanguage}");
                return id;
            }
        }
    
    }
}
