﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace Barely.Util {
    public static class Input {

        static KeyboardState keyboardState;
        static KeyboardState lastKeyboardState;
        static MouseState mouseState;
        static MouseState lastMouseState;
        static GameWindow gameWindow;

        public static void Initialize(GameWindow window) {            
            mouseState = Mouse.GetState();
            lastMouseState = mouseState;
            keyboardState = Keyboard.GetState();
            lastKeyboardState = keyboardState;
            gameWindow = window;
            
        }

        public static void AddToTextInputEvent(EventHandler<TextInputEventArgs> ev) {
            gameWindow.TextInput += ev;
        }

        public static void Update() {
            lastMouseState = mouseState;
            mouseState = Mouse.GetState();
            lastKeyboardState = keyboardState;
            keyboardState = Keyboard.GetState();            
        }

        public static bool WasAnyMouseClick() {

            //TODO

            return GetLeftMouseUp() || GetRightMouseUp() || GetMiddleMouseUp();
        }


        public static Point GetMousePosition() {
            return mouseState.Position;
        }

        public static Point GetMousePositionDelta() {
            return mouseState.Position - lastMouseState.Position;
        }

        public static bool GetLeftMouseDown() {
            return mouseState.LeftButton == ButtonState.Pressed && lastMouseState.LeftButton == ButtonState.Released;
        }

        public static bool GetRightMouseDown() {
            return mouseState.RightButton == ButtonState.Pressed && lastMouseState.RightButton == ButtonState.Released;
        }

        public static bool GetMiddleMouseDown() {
            return mouseState.MiddleButton == ButtonState.Pressed && lastMouseState.MiddleButton == ButtonState.Released;
        }


        public static bool GetLeftMouseUp() {
            return mouseState.LeftButton == ButtonState.Released && lastMouseState.LeftButton == ButtonState.Pressed;
        }
        public static bool GetRightMouseUp() {
            return mouseState.RightButton == ButtonState.Released && lastMouseState.RightButton == ButtonState.Pressed;
        }

        public static bool GetMiddleMouseUp() {
            return mouseState.MiddleButton == ButtonState.Released && lastMouseState.MiddleButton == ButtonState.Pressed;
        }


        public static bool GetLeftMousePressed() {
            return mouseState.LeftButton == ButtonState.Pressed;
        }
        public static bool GetRightMousePressed() {
            return mouseState.RightButton == ButtonState.Pressed;
        }

        public static bool GetMiddleMousePressed() {
            return mouseState.MiddleButton == ButtonState.Pressed;
        }

        public static int GetMouseWheelDelta() {
            return mouseState.ScrollWheelValue - lastMouseState.ScrollWheelValue;
        }
        
        public enum MouseButton { Left, Middle, Right}

        public static bool GetMouseUp(MouseButton but) {
            switch(but)
            {
                case MouseButton.Left:
                    return GetLeftMouseUp();
                case MouseButton.Middle:
                    return GetMiddleMouseUp();
                case MouseButton.Right:
                    return GetRightMouseUp();
                default:
                    return false;
            }
        }

        public static bool GetMouseDown(MouseButton but)
        {
            switch(but)
            {
                case MouseButton.Left:
                    return GetLeftMouseDown();
                case MouseButton.Middle:
                    return GetMiddleMouseDown();
                case MouseButton.Right:
                    return GetRightMouseDown();
                default:
                    return false;
            }
        }

        public static bool GetMousePressed(MouseButton but)
        {
            switch(but)
            {
                case MouseButton.Left:
                    return GetLeftMousePressed();
                case MouseButton.Middle:
                    return GetMiddleMousePressed();
                case MouseButton.Right:
                    return GetRightMousePressed();
                default:
                    return false;
            }
        }

        public static bool GetKeyDown(Keys key) {
            return keyboardState.IsKeyDown(key) && lastKeyboardState.IsKeyUp(key);
        }

        public static bool GetKeyUp(Keys key) {
            return keyboardState.IsKeyUp(key) && lastKeyboardState.IsKeyDown(key);
        }

        public static bool GetKeyPressed(Keys key) {
            return keyboardState.IsKeyDown(key);
        }

        public static Keys[] GetAllPressedKeys() {
            return keyboardState.GetPressedKeys();
        }

    }
}
