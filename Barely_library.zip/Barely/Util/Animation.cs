﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Util {

    public class Animation {        
        public int currentFrame { get; protected set; }
        int animationFrames;
        bool looping { get { return TransitionTo == null; } }
        public Rectangle[] rects;
        public Point[] drawOffsets;
        public Color[] colors;
        public double leng;
        public double[] length;

        public Color stdColor = Color.White;
        public Point stdDrawOffset;

        private Animation TransitionTo = null;

        public Animation(int animationFrames, double length, Rectangle[] rects, Point[] drawOffsets = null, Color[] colors = null)
        {
            Debug.Assert(rects != null && (rects.Length == animationFrames || rects.Length == 1));
            Debug.Assert(drawOffsets == null || drawOffsets.Length == animationFrames);
            Debug.Assert(colors == null || colors.Length == animationFrames);
            
            this.animationFrames = animationFrames;
            currentFrame = 0;
            this.rects = rects;
            this.drawOffsets = drawOffsets;
            this.colors = colors;
            this.leng = length;
            this.length = null;
        }

        public Animation(int animationFrames, double[] length, Rectangle[] rects, Point[] drawOffsets = null, Color[] colors = null) {
            Debug.Assert(length != null && rects != null);
            Debug.Assert(length.Length == animationFrames && (rects.Length == animationFrames || rects.Length == 1));            
            Debug.Assert(drawOffsets == null || drawOffsets.Length == animationFrames);
            Debug.Assert(colors == null || colors.Length == animationFrames);
            
            this.animationFrames = animationFrames;
            currentFrame = 0;
            this.rects = rects;
            this.drawOffsets = drawOffsets;
            this.colors = colors;
            this.length = length;
            this.leng = 0.0;
        }
            
        public double LengthOfCurrentFrame() {
            if(length == null)
                return leng;
            else
                return length[currentFrame];
        }

        public void SetTransitionAnimation(Animation transitionTo)
        {
            TransitionTo = transitionTo;            
        }

        public bool Equals(Animation other) {
            return this.animationFrames.Equals(other.animationFrames) && this.rects.Equals(other.rects) && this.length.Equals(other.length) && this.looping.Equals(other.looping);
        }   

        void SetFrame(Sprite sprite, int index)
        {
            if (rects.Length > 1)
                sprite.spriteRect = rects[index];
            else
                sprite.spriteRect = rects[0];

            if (drawOffsets != null)
                sprite.drawOffset = drawOffsets[index];
            else
                sprite.drawOffset = stdDrawOffset;

            if (colors != null)
                sprite.color = colors[index];
            else
                sprite.color = Color.White;
        }

        public void SetFirstFrame(Sprite sprite)
        {
            SetFrame(sprite, 0);
        }

        public void GetNextFrame(Sprite sprite) {
            if(currentFrame < animationFrames - 1)
            {
                currentFrame++;
                SetFrame(sprite, currentFrame);
            } else
            {
                if(!looping)
                {
                    if(TransitionTo != null)
                    {
                        sprite.SetAnimation(TransitionTo);
                    }                    
                } else
                {
                    currentFrame = 0;
                    SetFrame(sprite, currentFrame);
                }
            }
        }

        public Animation CopyInstance() {
            if(length == null)
                return new Animation(animationFrames, leng, rects, drawOffsets, colors);
            else
                return new Animation(animationFrames, length, rects, drawOffsets, colors);
        }

    }
}