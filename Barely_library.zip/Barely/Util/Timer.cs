﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Util
{
    public class Timer
    {
        private static HashSet<Timer> activeTimers = new HashSet<Timer>();

        public static void UpdateAll(float dt)
        {
            foreach(Timer t in activeTimers)
            {
                t.Update(dt);
            }
            activeTimers.RemoveWhere((t) => t.PleaseRemove);
        }

        private static void Add(Timer t)
        {
            activeTimers.Add(t);
        }

        private static void Remove(Timer t)
        {
            activeTimers.Remove(t);
        }

        private readonly float totalTime;
        private float timeLeft;
        private Action OnFinished;
        private bool PleaseRemove = false;
        private bool IsStarted = false;

        /// <summary>
        /// Counts down the time, than calls OnFinished function. Can als be checked manually with IsFinished().
        /// To work in the main Loop the static method Timer.UpdateAll has to be called.
        /// </summary>
        /// <param name="length">In Seconds</param>
        /// <param name="OnFinished"></param>
        public Timer(float length, Action OnFinished)
        {
            timeLeft = length;
            totalTime = length;
            this.OnFinished = OnFinished;
            Add(this);
        }

        public Timer(float length)
        {
            timeLeft = length;
            totalTime = length;
            this.OnFinished = null;
            Add(this);
        }

        public Timer Start()
        {
            IsStarted = true;
            return this;
        }

        private void Update(float dt)
        {
            if (!IsStarted)
                return;

            timeLeft -= dt;
            if(timeLeft <= 0f)
            {
                timeLeft = 0f;
                if (OnFinished != null)
                    OnFinished();
                PleaseRemove = true;
            }
        }

        public bool IsFinished()
        {
            return timeLeft <= 0f;
        }



    }
}
