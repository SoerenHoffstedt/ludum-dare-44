﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Barely.Util {

    public static class Settings {

        public static bool debugRender = false;

        public static float camMinMovementSpeed = 900f;
        public static float camMaxMovementSpeed = 1200f;

        public static float maxZoom = 0.3f;
        public static float minZoom = 1f;


        public static bool buildingCosts = true;

        
        public static float timePerHour = 0.5f;
        public static double warningMessageOpenTime = 3.0;

        public static GraphicSettings graphicSettings;
        static List<DisplayMode> SupportedResolutions;
        public static Point Resolution { get { return graphicSettings.Resolution; } set { graphicSettings.Resolution = value; } }
        public static bool isFullscreen { get { return graphicSettings.isFullscreen; } set { graphicSettings.isFullscreen = value; } }
        public static bool isBorderless { get { return graphicSettings.isBorderless; } set { graphicSettings.isBorderless = value; } }
        public static RasterizerState rasterizationState { get { return graphicSettings.rasterizationState; } set { graphicSettings.rasterizationState = value; } }
        
        public static Action<Point> OnResolutionChange; 

        //--------------------References-------------------------------//
        static GraphicsDeviceManager graphicsDeviceManager;
        static GameWindow window;

        public static void Initialize(GraphicsDeviceManager graphics, GameWindow window, XmlDocument configXml, string configPath) {
            graphicsDeviceManager = graphics;
            Settings.window = window;

            SupportedResolutions = new List<DisplayMode>();
            foreach (DisplayMode mode in GraphicsAdapter.DefaultAdapter.SupportedDisplayModes)
            {
                SupportedResolutions.Add(mode);
            }
            XmlNode graphicsNode = configXml.SelectSingleNode("settings/graphics");
            graphicSettings = new GraphicSettings();
            graphicSettings.rasterizationState = new RasterizerState { MultiSampleAntiAlias = true, ScissorTestEnable = true };
            XmlNode resNode = graphicsNode.SelectSingleNode("Resolution"); 
            graphicSettings.Resolution = new Point(int.Parse(resNode.Attributes["width"].Value), int.Parse(resNode.Attributes["height"].Value));
            XmlNode posNode = graphicsNode.SelectSingleNode("WindowPosition");
            graphicSettings.WindowPosition = new Point(int.Parse(posNode.Attributes["x"].Value), int.Parse(posNode.Attributes["y"].Value));
            graphicSettings.isFullscreen = bool.Parse(graphicsNode.SelectSingleNode("isFullscreen").InnerText);
            graphicSettings.isBorderless = bool.Parse(graphicsNode.SelectSingleNode("isBorderless").InnerText);
        }

        public static void LoadFromFile(StreamReader sr) {

        }

        public static void SaveToFile(StreamWriter sw) {

        }

        public static void ApplayGraphicsSettings() {
            graphicsDeviceManager.IsFullScreen = isFullscreen;
            graphicsDeviceManager.PreferredBackBufferHeight = Resolution.Y;
            graphicsDeviceManager.PreferredBackBufferWidth = Resolution.X;
            graphicsDeviceManager.ApplyChanges();
            window.IsBorderless = isBorderless;
            if(!isFullscreen)
                window.Position = graphicSettings.WindowPosition;                
            OnResolutionChange?.Invoke(Resolution);
        }

        public static void ChangeFullscreen(bool isFullscreen) {
            Settings.isFullscreen = isFullscreen;
            graphicsDeviceManager.IsFullScreen = isFullscreen;
            graphicsDeviceManager.ApplyChanges();
        }

        public static void ChangeBorderless(bool isBorderless) {
            Settings.isBorderless = isBorderless;           
        }

    }
    
    public struct GraphicSettings
    {
        public Point Resolution;
        public Point WindowPosition;
        public bool isFullscreen;
        public bool isBorderless;
        public RasterizerState rasterizationState;        
    }
}
