﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Util
{
    public struct RectangleF
    {

        public float X;
        public float Y;
        public float W;
        public float H;

        public Vector2 Position { get { return new Vector2(X, Y); } }
        public Vector2 Size { get { return new Vector2(W, H); } }

        public RectangleF(float x, float y, float w, float h)
        {
            this.X = x;
            this.Y = y;
            this.W = w;
            this.H = h;
        }

        public RectangleF(Vector2 position, Vector2 size)
        {
            this.X = position.X;
            this.Y = position.Y;
            this.W = size.X;
            this.H = size.Y;
        }

    }
}
