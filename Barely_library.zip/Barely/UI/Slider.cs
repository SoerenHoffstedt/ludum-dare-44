﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Barely.Util;
using System.Diagnostics;

namespace Barely.Interface {    
    public class Slider : UIObject {

        public int steps;

        public Action<float> OnValueChanged;
        public Action<float> OnValueChangedEveryStep;

        public Slider(InterfaceManager ifManager, Point pos, Point size, Sprite bgSprite, Sprite slideAreaSprite, Sprite slideHandleSprite, 
                        Action<float> OnValueChangedEveryStep, Action<float> OnValueChanged = null, int steps = 100, int startPos = 30) 
                        : base(false, ifManager, true, pos, size, bgSprite) {

            this.OnValueChanged = OnValueChanged;
            this.OnValueChangedEveryStep = OnValueChangedEveryStep;
            int xBorders = 10;
            int areaHeight = size.Y - 20;
            int handleHeight = size.Y -10;
            this.steps = steps;

            SlideHandle handle = new SlideHandle(ifManager, new Point(xBorders + 20, size.Y / 2 - (handleHeight / 2)),
                    new Point(10, handleHeight), slideHandleSprite, xBorders, size.X - (2 * xBorders), startPos, this.steps, this);

            UIObject area = new SlideArea(ifManager, new Point(xBorders, size.Y / 2 - (areaHeight / 2)),
                    new Point(size.X - (2 * xBorders), areaHeight), slideAreaSprite, handle);

            handle.SetStartPos();

            UIObject[] childs = { area, handle};

            AddChild(childs);
        }

        public override void Render(SpriteBatch spriteBatch) {

        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {

            sprite?.Render(spriteBatch, new Rectangle(Position + parentPos, size));

            for(int i = 0; i < childObjects.Length; i++)
            {
                childObjects[i].RenderAsChild(spriteBatch, Position + parentPos);
            }            
        }




        protected class SlideArea : UIObject {

            Color color = Color.White;
            SlideHandle handle;

            public SlideArea(InterfaceManager ifManager, Point pos, Point size, Sprite sprite, SlideHandle handle) 
                : base(false, ifManager, true, pos, size, sprite) {

                this.handle = handle;
                ifManager.RegisterUIObjectToHandleInputAsFirstLevel(this);
            }

            public override void MouseEnter() {
                base.MouseEnter();
                color = Colors.veryLightGray;
            }

            public override void MouseExit() {
                base.MouseExit();
                color = Color.White;
            }
            

            public override void LeftMouseClick(Point clickPos) {
                base.LeftMouseClick(clickPos);       
                handle.HandleAreaClick(clickPos.X - Position.X);
            }

            public override void Render(SpriteBatch spriteBatch) {

            }

            public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {
                sprite.Render(spriteBatch, new Rectangle(parentPos + Position, size), color);
            }

        }




        protected class SlideHandle : UIObject {

            Color mouseOverColor = Color.White;
            bool isDragging = false;
            int minPos;
            int maxPos;
            int width { get { return maxPos - minPos; } }
            int steps;
            int startPos;
            float oneStep;
            float sliderPosPercent { get { return (float)(Position.X - minPos) / (float)(maxPos - minPos); } }

            Slider parent;

            public SlideHandle(InterfaceManager ifManager, Point pos, Point size, Sprite sprite, int minPos, int maxPos, int startPos, int steps, Slider parent) 
                : base(false, ifManager, true, new Point( minPos, pos.Y), size, sprite) {
                this.steps = steps;
                this.parent = parent;
                this.minPos = minPos;
                this.maxPos = maxPos;
                this.startPos = startPos;
                this.X = (maxPos - minPos) * startPos + minPos;

                oneStep = (float)width / (float)steps;
                Debug.WriteLine($"Slider Handle step size: ({maxPos} - {minPos})/{steps} = {oneStep}");
                ifManager.RegisterUIObjectToHandleInputAsFirstLevel(this);
            }

            public void SetStartPos() {
                this.X =(int)((float)width * ((float)startPos/(float)100) + (float)minPos);
            }

            public void HandleAreaClick(int xPos) {
                xPos += size.X / 2;
                if(xPos >= maxPos - 10)
                    this.X = maxPos;
                else if(xPos <= minPos + 10)
                    this.X = minPos;
                else if(xPos > minPos && xPos < maxPos)
                    this.X = xPos;

                 if((Position.X - minPos) % steps != 0) {
                    //position.X = Math.Round()
                 }

                if(parent.OnValueChangedEveryStep != null)
                    parent.OnValueChangedEveryStep(sliderPosPercent);
                else if(parent.OnValueChanged != null)
                    parent.OnValueChanged(sliderPosPercent);

            }

            public override void MouseEnter() {
                base.MouseEnter();
                mouseOverColor = Colors.veryLightGray;
            }

            public override void MouseExit() {
                base.MouseExit();
                mouseOverColor = Color.White;
            }

            public override void LeftMouseDown() {
                isMouseDown = true;
                isDragging = true;
            }

            public override void LeftMousePressed() {
                if(isDragging)
                {
                    mouseOverColor = Colors.veryLightGray;
               
                    this.X = Input.GetMousePosition().X - parentPos.X - minPos;
                    
                    if(this.X < minPos)
                        this.X = minPos;
                    if(this.X > maxPos)
                        this.X = maxPos;

                    if(parent.OnValueChangedEveryStep != null)
                        parent.OnValueChangedEveryStep(sliderPosPercent);
                    else if(parent.OnValueChanged != null)
                        parent.OnValueChanged(sliderPosPercent);
                }
            }

            public override void LeftMouseClick(Point clickPos) {

                isMouseDown = false;

                if(parent.OnValueChangedEveryStep != null)
                    parent.OnValueChangedEveryStep(sliderPosPercent);
                else if(parent.OnValueChanged != null)
                    parent.OnValueChanged(sliderPosPercent);

                if(!isMouseOver)
                    mouseOverColor = Color.White;
            }


            public override void Render(SpriteBatch spriteBatch) {
                
            }

            public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {
                sprite.Render(spriteBatch, new Rectangle(parentPos + Position /*- new Point(size.X / 2, 0)*/, size), mouseOverColor);
            }
        }
    }
}
