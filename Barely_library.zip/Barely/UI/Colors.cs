﻿using Microsoft.Xna.Framework;

namespace Barely.Interface {
    public static class Colors {
        public readonly static Color buildOkay = new Color(Color.Gray, 0.7f);
        public readonly static Color buildFalse = new Color(Color.MediumVioletRed, 0.7f);
        public readonly static Color destory = new Color(Color.IndianRed, 0.8f);
        public readonly static Color orange = new Color(215, 126, 8);
        public readonly static Color gray = new Color(51, 51, 51, 250);
        public readonly static Color darkGray = new Color(31, 31, 31);
        public readonly static Color lightGray = new Color(70, 70, 70);
        public readonly static Color veryLightGray = new Color(200, 200, 200);
        public readonly static Color wine = new Color(146, 0, 37);
        public readonly static Color notRealWhite = new Color(227, 221, 209);
        public readonly static Color panelFrameGray = new Color(45, 45, 45);
    }
}
