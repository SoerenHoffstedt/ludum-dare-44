﻿using System;
using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Barely.Interface
{
    public class Log : UIObject
    {
        string[] lines;
        


        public Log(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, Sprite sprite, int maxLines = 20) 
            : base(isFirstLevelObject, ifManager, true, pos, size, sprite)
        {
            lines = new string[maxLines];
        }

        public override void Render(SpriteBatch spriteBatch)
        {
            RenderAsChild(spriteBatch, Point.Zero);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            if(!isOpen)
                return;

            throw new NotImplementedException();
        }
    }
}
