﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using System.Diagnostics;
using Barely.Util;
using System.Xml;
using Glide;

namespace Barely.Interface {

    public enum Anchor { TopLeft, TopMiddle, TopRight, MiddleLeft, MiddleMiddle, MiddleRight, BottomLeft, BottomMiddle, BottomRight }
    public enum Pivot { TopLeft, TopMiddle, TopRight, MiddleLeft, MiddleMiddle, MiddleRight, BottomLeft, BottomMiddle, BottomRight }
    public enum SpriteState { Normal = 0, MouseOver = 1, MouseDown = 2, Inactive = 3 }

    public enum FontSize { Small, Normal, Big }

    public class InterfaceManager {

        public static Tweener tweener = new Tweener();

        public SpriteFont NormalFont;
        public SpriteFont SmallFont;
        public SpriteFont BigFont;

        public SpriteFont[] fonts;
        public Texture2D uiAtlas;

        public Dialog dialogWindow;

        public Point GetResolution { get { return _getResolution(); } }

        Func<Point> _getResolution;

        XmlDocument xmlInterface;
        public GraphicsDevice GraphicsDevice;
        ContentManager Content;

        List<Button> buttons;
        public List<TextLabel> textLabels;
        public List<UIObject> allUIObjects;
        List<Panel> allPanels;
        List<UIObject> UIObjectsWithMouseDownFocus;        

        IFocusable focusedObject = null;
        Window openWindow = null;
        Stack<Window> lastWindows = new Stack<Window>();


        public Sprite closeButtonSprite;
        public Sprite buttonSprite;
        public Sprite titleBar;
        public Sprite sliderBG;
        public Sprite sliderArea;
        public Sprite sliderHandle;

        public Sprite firstPanel;
        public Sprite secondPanel;
        public Sprite thirdPanel;
        public Sprite framePanel;
        public Sprite textInputPanel;
        public Sprite tooltipPanel;

        public Sprite sortableListHeadButton;
        public Sprite sortableListEntry;
        public Sprite dropdownEntry;
        public Sprite dropdownLeftMain;
        public Sprite dropdownRightMain;
        public Sprite dropdownArrow;
        public Sprite backSprites;
        public Sprite scrollUp;
        public Sprite scrollDown;
        public Sprite titleBarSprite;

        public Sprite textCursor;

        public Sprite scrollBarBackground;
        public Sprite scrollBarHandle;

        public Sprite speedPause;
        public Sprite speedNormal;
        public Sprite speedFast;
        public Sprite speedFaster;
        public Color[] speedButtonsNormalColors;
        public Color[] speedButtonsSelectedColors;

        public Sprite numberChangerButtonPlus;
        public Sprite numberChangerButtonMinus;
        public Sprite numberChangerBG;

        public Sprite checkboxBackground;
        public Sprite checkboxSelectedGraphic;

        public Sprite radioButton;
        public Sprite radioButtonSelectedGraphic;

        public Sprite normalTabButton;
        public Sprite selectedTabButton;

        public Sprite listSelectedBackground;

        public Sprite windowOpenBackground;
        private bool showWindowOpenBackground = true;

        private Dictionary<string, Color> colors;

        public bool hasFocus { get { return focusedObject != null || openWindow != null; } }    //openWindows.Count > 0; } }

       public InterfaceManager(Texture2D atlas, GraphicsDevice graphics, ContentManager Content, Func<double> tooltipTime, Func<Point> getResolution) {
            this.uiAtlas = atlas;
            this.xmlInterface = null;
            this.GraphicsDevice = graphics;
            this.Content = Content;
            allUIObjects = new List<UIObject>();
            buttons = new List<Button>();
            textLabels = new List<TextLabel>();
            allPanels = new List<Panel>();
            UIObjectsWithMouseDownFocus = new List<UIObject>();

            UIObject.tooltipTime = tooltipTime;
            UIObject.ShowTooltip = ShowTooltip;
            _getResolution = getResolution;
        }

        public InterfaceManager(Texture2D atlas, XmlDocument xmlInterface, GraphicsDevice graphics, ContentManager Content) {
            this.uiAtlas = atlas;
            this.xmlInterface = xmlInterface;
            this.GraphicsDevice = graphics;
            this.Content = Content;
            allUIObjects = new List<UIObject>();
            buttons = new List<Button>();
            textLabels = new List<TextLabel>();
            allPanels = new List<Panel>();
            UIObjectsWithMouseDownFocus = new List<UIObject>();

            Texture2D closeButtonAtlas = Content.Load<Texture2D>("Icons/cancel");
            closeButtonSprite = new Sprite(closeButtonAtlas, new Rectangle(0, 0, 512, 512), Colors.orange);
          

            buttonSprite = new Sprite9Slice(uiAtlas, new Rectangle(16 * 32, 2 * 32, 32, 32), Color.White, 6, 6, 6, 6);
              


            titleBar = new Sprite9Slice(uiAtlas, new Rectangle(14 * 32, 1 * 32, 32, 32), Color.White, 4, 4, 0, 4);
            textInputPanel = new Sprite9Slice(uiAtlas, new Rectangle(13 * 32, 0, 32, 32), Color.White, 6, 6, 6, 6);
            firstPanel = new Sprite9Slice(uiAtlas, new Rectangle(17 * 32, 3 * 32, 32, 32), Color.White, 6, 6, 6, 6);

            sliderBG = new Sprite9Slice(uiAtlas, new Rectangle(13 * 32, 1 * 32, 32, 32), Color.White, 6, 6, 6, 6);
            sliderHandle = new Sprite9Slice(uiAtlas, new Rectangle(480, 32, 5, 15), Color.White, 1, 1, 1, 1);
            sliderArea = new Sprite9Slice(uiAtlas, new Rectangle(480, 53, 32, 11), Color.White, 5, 5, 5, 5);

            
            dropdownEntry = new Sprite9Slice(uiAtlas, new Rectangle(512,43,32,10), Color.White, 2,2,0,2);
            
            dropdownLeftMain = new Sprite9Slice(uiAtlas, new Rectangle(512,32, 17,11), Color.White, 2, 2, 2, 2);
            dropdownRightMain = new Sprite9Slice(uiAtlas, new Rectangle(529, 32, 15, 11), Color.White, 2, 2, 2, 2);
            dropdownArrow = new Sprite(uiAtlas, new Rectangle(544,322,9,7), Color.White);
            
            scrollDown = new Sprite(uiAtlas, new Rectangle(544,32,9,6), Color.White);

            numberChangerButtonPlus     = new Sprite9Slice(uiAtlas, new Rectangle(448, 0, 32, 32), Color.White, 5, 5, 5, 5);
            numberChangerButtonMinus    = new Sprite(uiAtlas, new Rectangle(448, 0, 32, 32), Color.White);
            numberChangerBG             = new Sprite(uiAtlas, new Rectangle(448, 0, 32, 32), Color.White);

        scrollUp = new Sprite(uiAtlas, new Rectangle(544, 38, 9, 6), Color.White);
            

            Texture2D backTex = Content.Load<Texture2D>("Icons/plain-arrow");
            
            backSprites = new Sprite(backTex, new Rectangle(0, 0, 256, 256), Color.White);
           
            secondPanel     = new Sprite9Slice(uiAtlas, new Rectangle(14 * 32, 2 * 32, 32, 32), Color.White, 10, 10, 10, 10);

            framePanel      = new Sprite9Slice(uiAtlas, new Rectangle(20 * 32, 0 * 32,32,32), Color.White, 3,3,3,3);
            
            titleBarSprite  = new Sprite9Slice(uiAtlas, new Rectangle(14 * 32, 1 * 32, 32, 32), Color.White, 4, 4, 4, 4);


            speedButtonsNormalColors = new [] { Color.White, Colors.veryLightGray, Colors.lightGray, Colors.gray };
            Vector3 orange = Colors.orange.ToVector3();           
            speedButtonsSelectedColors = new[] { Colors.orange, new Color(orange * 0.9f), new Color(orange * 0.8f), new Color(orange * 0.6f)};

            speedPause      = new Sprite(Content.Load<Texture2D>("Icons/speedPause"), new Rectangle(0, 0, 50, 50), Color.White);                                                                
            speedNormal     = new Sprite(Content.Load<Texture2D>("Icons/speedNormal"), new Rectangle(0, 0, 50, 50), Color.White);                                                
            speedFast       = new Sprite(Content.Load<Texture2D>("Icons/speedFast"), new Rectangle(0, 0, 50, 50), Color.White);
            speedFaster     = new Sprite(Content.Load<Texture2D>("Icons/speedFaster"), new Rectangle(0, 0, 50, 50), Color.White);

            scrollBarBackground = new Sprite9Slice(uiAtlas, new Rectangle(480, 96, 7, 17), Color.White, 3, 3, 3, 3);
            scrollBarHandle = new Sprite9Slice(uiAtlas, new Rectangle(488, 96, 5, 10), Color.White, 1, 1, 1, 1);

            tweener = new Tweener();

            BigFont     = Content.Load<SpriteFont>("Segoe_UI_18");
            NormalFont  = Content.Load<SpriteFont>("Segoe_UI_15_Regular");
            SmallFont   = Content.Load<SpriteFont>("Segoe_UI_12");
            BigFont.LineSpacing     = 18;
            NormalFont.LineSpacing  = 18;
            SmallFont.LineSpacing   = 16;
            LoadFromXml(xmlInterface.SelectSingleNode("barelyUI"));

        }

        void LoadFromXml(XmlNode node) {
            colors = new Dictionary<string, Color>();
            foreach(XmlNode colorNode in node.SelectNodes("colors/color")) {
                string id = colorNode.Attributes["id"].Value;
                byte r = Byte.Parse(colorNode.Attributes["r"].Value);
                byte g = Byte.Parse(colorNode.Attributes["g"].Value);
                byte b = Byte.Parse(colorNode.Attributes["b"].Value);
                byte a = Byte.Parse(colorNode.Attributes["a"].Value);                
                colors.Add(id, new Color(r, g, b, a));
            }

            /*buttonSprites = LoadButtonSpritesFromXmlStyle(node.SelectSingleNode("button1"));
            numberChangerButton = LoadButtonSpritesFromXmlStyle(node.SelectSingleNode("numberChangerButton"));
            numberChangerBG = LoadSpriteFromXmlStyle(node.SelectSingleNode("numberChangerBackground"));
            checkboxBackground = LoadButtonSpritesFromXmlStyle(node.SelectSingleNode("checkboxBackground"));
            checkboxSelectedGraphic = LoadSpriteFromXmlStyle(node.SelectSingleNode("checkBoxSelectionGraphic"));
            radioButtons = checkboxBackground;
            radioButtonSelectedGraphic = checkboxSelectedGraphic;
            */
        }

        Sprite[] LoadButtonSpritesFromXmlStyle(XmlNode node) {
            Sprite[] sprites = new Sprite[4];
            bool colorSprites = false;            

            XmlNodeList spriteNodes = node.SelectNodes("sprite");
            if (spriteNodes.Count == 1) {
                colorSprites = true;
                if(spriteNodes[0].SelectNodes("color").Count != 4) {
                    throw new Exception($"Barely UI Style, {node.Attributes["id"]?.Value}: A button definition with one sprite needs four color values as children elements.");
                }                
            } else if(spriteNodes.Count == 4) {
                colorSprites = false;
            } else {
                throw new Exception($"Barely UI Style, {node.Attributes["id"]?.Value}: A button definition needs either 4 sprites or 1 sprite with 4 color child elements.");
            }
            

            if(colorSprites) {
                XmlNode spriteNode      = spriteNodes[0];
                XmlNodeList colorNodes  = spriteNode.SelectNodes("color");
                Color[] colors          = new Color[4];
                bool is9Slice           = false;
                XmlNode marginNode      = spriteNode.SelectSingleNode("margin");
                is9Slice                = marginNode != null;

                Texture2D tex   = Content.Load<Texture2D>(spriteNode.Attributes["texture"].Value);
                int x           = int.Parse(spriteNode.Attributes["x"].Value);
                int y           = int.Parse(spriteNode.Attributes["y"].Value); 
                int w           = int.Parse(spriteNode.Attributes["width"].Value);
                int h           = int.Parse(spriteNode.Attributes["height"].Value);
                Rectangle rect  = new Rectangle(x, y, w, h);

                for(int i= 0; i < colorNodes.Count; i++) {
                    int index = int.Parse(colorNodes[i].Attributes["index"].Value);
                    colors[index] = GetColorFromXmlStyle(colorNodes[i]);
                }

                Sprite spr;
                if(is9Slice) {
                    int l = int.Parse(marginNode.Attributes["left"].Value);
                    int r = int.Parse(marginNode.Attributes["right"].Value);
                    int u = int.Parse(marginNode.Attributes["up"].Value);
                    int d = int.Parse(marginNode.Attributes["down"].Value);
                    for(int i = 0; i < 4; i++) {
                        sprites[i] = new Sprite9Slice(tex, rect, colors[i], l, r, u, d);
                    }

                } else {
                    for (int i = 0; i < 4; i++)                    
                        sprites[i] = new Sprite(tex, rect, colors[i]);                    
                }


            } else {
                for(int i = 0; i < 4; i++) {
                    XmlNode spriteNode  = spriteNodes[i];
                    Texture2D tex       = Content.Load<Texture2D>(spriteNode.Attributes["texture"].Value);
                    int x               = int.Parse(spriteNode.Attributes["x"].Value);
                    int y               = int.Parse(spriteNode.Attributes["y"].Value);
                    int w               = int.Parse(spriteNode.Attributes["width"].Value);
                    int h               = int.Parse(spriteNode.Attributes["height"].Value);
                    Rectangle rect      = new Rectangle(x, y, w, h);
                    
                    Color c             = Color.White;
                    XmlNode colorNode   = spriteNode.SelectSingleNode("color");
                    if (colorNode != null) {
                        c = GetColorFromXmlStyle(colorNode);
                    }

                    XmlNode marginNode  = spriteNode.SelectSingleNode("margin");
                    bool is9Slice       = marginNode != null;
                    if(is9Slice) {
                        int l = int.Parse(marginNode.Attributes["left"].Value);
                        int r = int.Parse(marginNode.Attributes["right"].Value);
                        int u = int.Parse(marginNode.Attributes["up"].Value);
                        int d = int.Parse(marginNode.Attributes["down"].Value);

                        sprites[i] = new Sprite9Slice(tex, rect, c, l, r, u, d);
                    } else {
                        sprites[i] = new Sprite(tex, rect, c);
                    }

                }
            }
            

            return sprites;
        }

        Sprite LoadSpriteFromXmlStyle(XmlNode node) {
            Sprite spr;
            node = node.SelectSingleNode("sprite");
            Color c = Color.White;
            XmlNode colorNode = node.SelectSingleNode("color");
            if (colorNode != null)
                c = GetColorFromXmlStyle(colorNode);
            Texture2D tex = Content.Load<Texture2D>(node.Attributes["texture"].Value);

            int x = int.Parse(node.Attributes["x"].Value);
            int y = int.Parse(node.Attributes["y"].Value);
            int w = int.Parse(node.Attributes["width"].Value);
            int h = int.Parse(node.Attributes["height"].Value);
            Rectangle rect = new Rectangle(x, y, w, h);

            XmlNode marginNode = node.SelectSingleNode("margin");
            if (marginNode != null) {
                int l = int.Parse(marginNode.Attributes["left"].Value);
                int r = int.Parse(marginNode.Attributes["right"].Value);
                int u = int.Parse(marginNode.Attributes["up"].Value);
                int d = int.Parse(marginNode.Attributes["down"].Value);

                spr = new Sprite9Slice(tex, rect, c, l, r, u, d);
            } else {
                spr = new Sprite(tex, rect, c);
            }

            return spr;
        }

        Color GetColorFromXmlStyle(XmlNode colorNode) {

            if (colorNode.Attributes["id"] == null)
            {
                byte r = Byte.Parse(colorNode.Attributes["r"].Value);
                byte g = Byte.Parse(colorNode.Attributes["g"].Value);
                byte b = Byte.Parse(colorNode.Attributes["b"].Value);
                byte a = Byte.Parse(colorNode.Attributes["a"].Value);

                return new Color(r, g, b, a);
            } else {
                return colors[colorNode.Attributes["id"].Value];
            }
        }

        public void ShowWindowOpenBackground(bool val) {
            showWindowOpenBackground = val;
        }

        public void Initialize()
        {            

        }

        public Tooltip tooltip;

        public void ShowTooltip(UIObject tooltipFor)
        {
            if(tooltipFor != null)
            {
                tooltip.Open(tooltipFor);
            } else
            {
                tooltip.Close();
            }
        }

        public SpriteFont GetFont(string val) {
            switch(val)
            {
                case "Small":
                    return SmallFont;
                case "Normal":
                    return NormalFont;
                case "Big":
                    return BigFont;
                default:
                    return NormalFont;
            }   
        }

        public SpriteFont GetFont(FontSize size) {
            switch(size)
            {
                case FontSize.Small:
                    return SmallFont;
                case FontSize.Normal:
                    return NormalFont;
                case FontSize.Big:
                    return BigFont;
                default:
                    return NormalFont;
            }
        }

        public void ReloadAllTexts() {
            for(int i = 0; i < textLabels.Count; i++) {
                textLabels[i]?.ReloadText();
            }
        }

        Sprite[] CreateButtonSpritesWithColor(Texture2D atlas, Rectangle rect, Color normal, Color mouseOver, Color mouseDown, Color inactive) {
            var tmp = new Sprite[4];
            tmp[0] = new Sprite(atlas, rect, normal);
            tmp[1] = new Sprite(atlas, rect, mouseOver);
            tmp[2] = new Sprite(atlas, rect, mouseDown);
            tmp[3] = new Sprite(atlas, rect, inactive);
            return tmp;
        }


        public void RegisterUIObject(UIObject obj) {
            allUIObjects.Add(obj);            
        }

        public void RegisterUIObjectToHandleInputAsFirstLevel(UIObject obj) {
            UIObjectsWithMouseDownFocus.Add(obj);
        }

        public void RegisterButton(Button but) {
            buttons.Add(but);
        }

        public void RegisterPanel(Panel panel) {
            allPanels.Add(panel);
        }

        public void BackToLastWindow() {
            if(openWindow != null && lastWindows.Count > 0) {
                openWindow.Close();                
                openWindow = lastWindows.Pop();
                openWindow?.Open();                
            }
        }

        public void OpenWindow(Window windowObj) {
            if(openWindow != null)
            {
                lastWindows.Push(openWindow);
                openWindow.Close();
            } else if(lastWindows.Count > 0)
                lastWindows.Clear(); 
                


            openWindow = windowObj;
            //windowObj.Open();
        }

        public void CloseWindow(Window windowObj) {
            openWindow = null;                        

            if(windowObj.isOpen)
            {
                windowObj.isOpen = false;
                
            }

        }

        public void FocusObject(IFocusable focusObj) {
            if(focusedObject != null)
            {
                focusedObject.OnLooseFocus();
            }

            focusedObject = focusObj;
            focusObj.OnGainFocus();

        }

        public void UnFocusObject(IFocusable focusObj) {
            if(focusedObject == focusObj)
                focusObj.OnLooseFocus();

            focusedObject = null;
        }

      
        public void LoadContent() { 
        }

        public void UnloadContent() {
            uiAtlas.Dispose();            
        }

        public void Update(double deltaTime) {

            foreach(UIObject obj in allUIObjects)
            {
                obj.Update(deltaTime);
            }

            tweener?.Update((float)deltaTime);
        }

        public void Render(SpriteBatch batch) {

            for(int i = 0; i < allUIObjects.Count; i++){
                UIObject obj = allUIObjects[i];
                if(obj != openWindow && obj != tooltip)
                    obj?.Render(batch);
            }

            if(openWindow != null) {
                //draw gray background
                windowOpenBackground?.Render(batch, new Rectangle(0, 0, 1920, 1080));
                openWindow.Render(batch);
            }

            tooltip?.Render(batch);
           
        }

        UIObject lastMouseOver;

        public bool HandleInput() {
            Point mousePos = Input.GetMousePosition();
            Point localMousePos = mousePos;
            bool handled = false;
            UIObject newLastMouseOver = null;

            
            foreach(UIObject objRun in UIObjectsWithMouseDownFocus)
            {
                if(objRun.isMouseOver && objRun != newLastMouseOver)
                {
                    objRun.MouseExit();
                } else if(objRun.isMouseDown)
                {

                    if(Input.GetLeftMousePressed())
                        objRun.LeftMousePressed();
                    else if(Input.GetLeftMouseUp())
                        objRun.LeftMouseClick(localMousePos);

                    handled = true;
                }
            }

            for(int i = 0; i < allUIObjects.Count; i++)
            {
                UIObject objRun = allUIObjects[i];  

                if(!handled && objRun != null && objRun.Interactable && (openWindow == null || objRun == openWindow) && mousePos.X >= objRun.Position.X && mousePos.X <= objRun.Position.X + objRun.size.X
                    && mousePos.Y >= objRun.Position.Y && mousePos.Y <= objRun.Position.Y + objRun.size.Y)
                {
                    var obj = objRun;

                    if(objRun.ChildObjects != null)
                    {
                        obj = objRun.FindMouseOverChild(mousePos, ref localMousePos);
                    }

                    if (focusedObject != null && obj != focusedObject && Input.WasAnyMouseClick())
                    {
                        focusedObject.OnLooseFocus();
                    }

                    if (Input.GetLeftMouseUp())
                    {
                        obj.LeftMouseClick(localMousePos);

                    } else if(Input.GetLeftMouseDown())
                    {
                        obj.LeftMouseDown();
                    } else if(Input.GetLeftMousePressed())
                    {
                        obj.LeftMousePressed();
                    } else if(Input.GetRightMouseUp())
                    {
                        obj.RightMouseClick();
                    } else if(Input.GetRightMouseDown())
                    {

                    } else if(Input.GetRightMousePressed())
                    {

                    } else if(Input.GetMiddleMouseUp())
                    {

                    } else if(Input.GetMiddleMouseDown())
                    {

                    } else if(Input.GetMiddleMousePressed())
                    {

                    } else if(Input.GetMouseWheelDelta() < 0)
                    {
                        obj.ScrollWheelDown();
                    } else if(Input.GetMouseWheelDelta() > 0) {
                        obj.ScrollWheelUp();
                    } else if(!obj.isMouseOver)
                    {
                        obj.MouseEnter();
                    } else
                    {
                        //Mouse Over
                        obj.MouseOver();
                    }
                  
                    newLastMouseOver = obj;
                    handled = true;
                } else if(objRun.isMouseOver)
                {
                    objRun.MouseExit();
                } else if(objRun.isMouseDown)
                {

                    if(Input.GetLeftMousePressed())
                        objRun.LeftMousePressed();
                    else if(Input.GetLeftMouseUp())
                        objRun.LeftMouseClick(localMousePos);
                }
            }


            if(lastMouseOver != null && lastMouseOver != newLastMouseOver)
            {
                if(lastMouseOver.isMouseOver)
                {
                    lastMouseOver.MouseExit();
                }
            }


            if(!handled && openWindow != null && ( Input.GetLeftMouseUp() || Input.GetRightMouseUp() || Input.GetMiddleMouseUp() )) {
                
                Sounds.Play("failedPlacement");
            }

            lastMouseOver = newLastMouseOver;

            return handled;
        }

        public void SetTotalPositions() {
            foreach(UIObject o in allUIObjects) {
                o.SetParentPos(Point.Zero);
            }
          
        }


        Point lastMouseScreenPosition;

        public bool MouseOverHandling(Point mouseScreenPosition) {
            foreach(Button obj in buttons)
            {
              
                if(mouseScreenPosition.X >= obj.Position.X && mouseScreenPosition.X <= obj.Position.X + obj.size.X
                    && mouseScreenPosition.Y >= obj.Position.Y && mouseScreenPosition.Y <= obj.Position.Y + obj.size.Y)
                {
                    obj.isMouseOver = true;
                    obj.spriteIndex = (int)SpriteState.MouseOver;
                    return true;
                } else if(obj.isMouseOver || obj.isMouseDown)
                {
                    obj.isMouseOver = false;
                    obj.spriteIndex = (int)SpriteState.Normal;
                }
            }
            return false;
        }
        
        public bool LeftMouseDown(Point clickScreenPosition) {
            foreach(Button obj in buttons)
            {
                if(clickScreenPosition.X >= obj.Position.X && clickScreenPosition.X <= obj.Position.X + obj.size.X
                    && clickScreenPosition.Y >= obj.Position.Y && clickScreenPosition.Y <= obj.Position.Y + obj.size.Y)
                {
                    obj.isMouseDown = true;
                    obj.spriteIndex = (int)SpriteState.MouseDown;
                    return true;
                } else if(obj.isMouseDown)
                {
                    obj.isMouseDown = false;
                    obj.spriteIndex = (int)SpriteState.Normal;
                }
            }
            return false;
        }

        public bool RightMouseDown(Point clickScreenPosition) {
            return false;
        }

        public bool LeftClickHandling(Point clickScreenPosition) {
            foreach(Button obj in buttons){
                if(clickScreenPosition.X >= obj.Position.X && clickScreenPosition.X <= obj.Position.X + obj.size.X
                    && clickScreenPosition.Y >= obj.Position.Y && clickScreenPosition.Y <= obj.Position.Y + obj.size.Y 
                    && obj.OnMouseUp != null)
                {
                    obj.OnMouseUp();
                    return true;
                }
            }
            return false;
        }

        public bool RightClickHandling(Point clickScreenPosition) {
            foreach (Button obj in buttons)
            {
                 if(clickScreenPosition.X >= obj.Position.X && clickScreenPosition.X <= obj.Position.X + obj.size.X
                    && clickScreenPosition.Y >= obj.Position.Y && clickScreenPosition.Y <= obj.Position.Y + obj.size.Y 
                    && obj.OnMouseUp != null)
                {
                    obj.OnMouseUp();
                    return true;
                }
            }
            return false;
        }
    }
}
