﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Barely.Util;
using System.Diagnostics;

namespace Barely.Interface {
    public class SortableListEntry<T> : Button where T : IListable<T> {

        public T element;
        object[] displayElements;
        SpriteFont font;
        Color textColor;
        Action<object[]> updateTexts;
        Action<bool> scrollAction;
        int eachElementWidth;
        float[] width;

        public SortableListEntry(T element, InterfaceManager ifManager, Point pos, Point size, Color textColor, float[] width, Action<T> OnEntryClick, Action<bool> scroll) 
            : base(false, ifManager, pos, size, ifManager.buttonSprite, null, () => { OnEntryClick?.Invoke(element); }) {
            this.element = element;
            this.textColor = textColor;
            this.width = width;
            this.scrollAction = scroll;
            displayElements = element.ListElementsToDisplay();
            updateTexts = element.GetElementUpdateDelegate();
            font = ifManager.SmallFont;

            eachElementWidth = size.X / displayElements.Length;
            OnMouseUp += () => Debug.WriteLine(element.ToString());
        }

        public void UpdateText() {
            updateTexts(displayElements);
        }

        public override void MouseEnter() {
            base.MouseEnter();
        }

        public override void MouseExit() {
            base.MouseExit();
        }

        public override void ScrollWheelDown()
        {
            scrollAction(true);
        }

        public override void ScrollWheelUp()
        {
            scrollAction(false);
        }

        public override void Render(SpriteBatch spriteBatch) {
            /*sprites[spriteIndex].Render(spriteBatch, new Rectangle(position, size));
            for(int i = 0; i < displayElements.Length; i++)
            {
                spriteBatch.DrawString(font, displayElements[i].ToString(),  position.ToVector2() + new Vector2(i * eachElementWidth + eachElementWidth/2, 0), textColor);
            }*/
            RenderAsChild(spriteBatch, Point.Zero);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {
            float positionAdd = 0f;
            sprite?.Render(spriteBatch, new Rectangle(Position + parentPos, size), colors[spriteIndex]);
            for(int i = 0; i < displayElements.Length; i++)
            {
                string str = displayElements[i].ToString();
                Vector2 strSize = font.MeasureString(str);
                int xOffset = (int)(strSize.X / 2);     

                spriteBatch.DrawString(font, str, parentPos.ToVector2() + Position.ToVector2() + new Vector2(positionAdd - xOffset + width[i] / 2, (size.Y - strSize.Y)/2), textColor);
                positionAdd += width[i];
            }
        }



    }
}
