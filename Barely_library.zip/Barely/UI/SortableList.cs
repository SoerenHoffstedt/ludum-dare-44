﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Barely.Util;
using System.Diagnostics;

namespace Barely.Interface {
    public class SortableList<T> : UIObject where T : IListable<T> {

        List<SortableListEntry<T>> listEntries;
        string[] elementHeadlines;
        object[] elementObjects;
        int entryElementsCount;

        ICollection<T> tCollection;

        Color textColor;
        SpriteFont font;
        int eachElementWidth;
        InterfaceManager ifManager;

        int entryHeight = 40;
        int entryDistance = 1;
        int entryYOffset = 52;
        int yMargin = 10;
        int xMargin = 10;
        int entryWidth;
        int scrollbarWidth = 20;
        int scrollbarXOffset = 4;

        Rectangle drawRect;

        ScrollBarHandle scrollbarHandle;
        ScrollBarBackground scrollbarBG;

        Vector2 scrollOffset;
        float maxYOffset;
        int entryTotalSizeY { get { return (entryHeight + 2 * entryDistance) * listEntries.Count; } }
        int displaySizeY;
        private GraphicsDevice GraphicsDevice;

        float[] width;

        public Action<T> OnEntryClick;        

        public SortableList(InterfaceManager ifManager, Point pos, Point size,
            Color textColor, ICollection<T> tCollection, T dummyObject, Action<T> OnEntryClick)
            : base(false, ifManager, true, pos, size, null) {

            this.GraphicsDevice = ifManager.GraphicsDevice;
            this.OnEntryClick = OnEntryClick;
            this.ifManager = ifManager;
            this.tCollection = tCollection;
            listEntries = new List<SortableListEntry<T>>();

            this.textColor = textColor;
            font = ifManager.SmallFont;
            elementHeadlines = dummyObject.DisplayingListElementsNames();
            elementObjects = dummyObject.ListElementsToDisplay();            
                        
            Action<List<SortableListEntry<T>>, bool>[] buttonActions = dummyObject.GetListSortingActions();

            entryWidth = size.X - 3 * xMargin - scrollbarWidth; 
            width = dummyObject.entryWidth();

            Button[] buttons = new Button[elementHeadlines.Length];

            for(int j = 0; j < width.Length; j++)
            {
                width[j] *= entryWidth;
            }

            int positionAdd = 0;
            for(int i = 0; i < elementHeadlines.Length; i++)
            {
                buttons[i] = new Button(false, ifManager,
                                        new Point(xMargin + positionAdd, yMargin),
                                        new Point((int)width[i], entryHeight),
                                        ifManager.buttonSprite,
                                        null, null);

                buttons[i].AddTextCaption(ifManager,
                                          elementHeadlines[i],
                                          textColor);
                int ind = i;
                buttons[i].OnMouseUp = () => {  buttonActions[ind](listEntries, SortBackward(elementObjects[ind])); SetNewEntryPositions(); };
                positionAdd += (int)width[i];
            }

            int count = 0;
            foreach(T t in tCollection)
            {
                listEntries.Add(new SortableListEntry<T>(t, ifManager, 
                                                        new Point(xMargin, entryYOffset + count * (entryHeight + 2 * entryDistance)), 
                                                        new Point(entryWidth, entryHeight), 
                                                        textColor, 
                                                        width, 
                                                        OnEntryClick, 
                                                        Scroll));
                count++;
            }

            entryElementsCount = elementHeadlines.Length;

            eachElementWidth = (size.X - 20) / elementHeadlines.Length;


            childObjects = new UIObject[elementHeadlines.Length];

            for(int i = 0; i < elementHeadlines.Length; i++)
            {
                childObjects[i] = buttons[i];
            }

            OnOpen += (obj) => {
                for(int i = 0; i < listEntries.Count; i++)
                {
                    listEntries[i].UpdateText();
                }
                /*if(!isOpen)
                {
                    isOpen = true;
                    ifManager.OpenWindow(this);
                }*/
            };

            OnClose += (obj) => {
                /*if(isOpen)
                {
                    isOpen = false;
                    ifManager.CloseWindow(this);
                }*/
            };
          
            //Scrollbar:
            scrollbarBG = new ScrollBarBackground(ifManager,
                                                  new Point(xMargin + scrollbarXOffset + entryWidth, entryHeight + yMargin),
                                                  new Point(scrollbarWidth, size.Y - entryHeight - 2 * yMargin),
                                                  this);

            scrollbarHandle = new ScrollBarHandle(ifManager,
                                                    new Point(xMargin + scrollbarXOffset + entryWidth + 4, entryHeight + yMargin + 4),
                                                    new Point(scrollbarWidth - 8, 50),
                                                    scrollbarBG, 
                                                    this);

            AddChild(new UIObject[] { scrollbarBG, scrollbarHandle });

            drawRect = new Rectangle(Position.X + xMargin, 
                                     Position.Y + yMargin, 
                                     entryWidth + scrollbarWidth + scrollbarXOffset, 
                                     size.Y - 2* yMargin);
            displaySizeY = size.Y - 2 * yMargin - entryHeight - entryDistance;
            ResetMaxOffsetAndHandlePos();

            //sprite = ifManager.secondPanel;
        }
     
        float timer = 0f;

        public override void Update(double deltaTime) {
            if(!isOpen)
                return;

            base.Update(deltaTime);

            timer += (float)deltaTime;
            if(timer >= 0.125f)
                for(int i = 0; i < listEntries.Count; i++)
                    listEntries[i].UpdateText();

            if(timer >= 0.25f)
            {
                if(tCollection.Count == 0 && listEntries.Count > 0)
                {
                    listEntries.RemoveRange(0, listEntries.Count);
                    SetNewEntryPositions();
                    ResetMaxOffsetAndHandlePos();
                }
                else if(tCollection.Count > listEntries.Count)
                {
                    foreach(T elem in tCollection)
                    {

                        if(listEntries.Any((e) => e.element.Equals(elem)))
                            continue;

                        var newOne = new SortableListEntry<T>(elem, ifManager, 
                                                              new Point(xMargin, 140 + (listEntries.Count - 1) * (entryHeight + 2 * entryDistance)), 
                                                              new Point(entryWidth, entryHeight), 
                                                              textColor, 
                                                              width, 
                                                              OnEntryClick, 
                                                              Scroll);
                        listEntries.Add(newOne);
                    }
                    SetNewEntryPositions();
                    ResetMaxOffsetAndHandlePos();
                } else if(tCollection.Count < listEntries.Count)
                {
                    HashSet<SortableListEntry<T>> toRemove = new HashSet<SortableListEntry<T>>();

                    for(int i = 0; i < listEntries.Count; i++)
                    {

                        if(!tCollection.Contains(listEntries[i].element))
                        {
                            toRemove.Add(listEntries[i]);                            
                        }
                    }

                    foreach(SortableListEntry<T> entry in toRemove)
                    {
                        listEntries.Remove(entry);
                    }

                    SetNewEntryPositions();
                    ResetMaxOffsetAndHandlePos();
                }                

                timer = 0f;
            }
        }

        object lastSortedObject = null;

        bool SortBackward(object obj) {

            if(lastSortedObject == obj)
            {

                lastSortedObject = null;
                return true;
            } else
            {
                lastSortedObject = obj;
                return false;
            }
        }

        void SetScrollOffset(float factor) {
            scrollOffset.Y = factor * maxYOffset;
        }

        void Scroll(bool scrollDown)
        {
            if(scrollDown)
            {
                ScrollWheelDown();
            } else
            {
                ScrollWheelUp();
            }
        }
       
        public override void ScrollWheelUp()
        {
            scrollOffset.Y += Input.GetMouseWheelDelta() / 2;

            if(scrollOffset.Y > 0)
                scrollOffset.Y = 0;
            if(scrollOffset.Y < maxYOffset)
                scrollOffset.Y = maxYOffset;

            scrollbarHandle.SetHandlePosition(scrollOffset.Y / maxYOffset);
        }

        public override void ScrollWheelDown()
        {
            ScrollWheelUp();
        }

        public override UIObject FindMouseOverChild(Point mousePos, ref Point localMousePos)
        {
            if(childObjects == null)            
                return this;
            
            UIObject toReturn = this;
            mousePos -= Position;
            localMousePos = mousePos;

            for(int i = 0; i < childObjects.Length; i++)
            {
                if(childObjects[i] == null)
                    continue;

                if(new Rectangle(childObjects[i].Position, childObjects[i].size).Contains(mousePos))
                {
                    if(childObjects[i].Interactable)
                    {
                        if(childObjects[i].childObjects != null)
                            toReturn = childObjects[i].FindMouseOverChild(mousePos, ref localMousePos);
                        else
                            toReturn = childObjects[i];
                    }
                } else if(childObjects[i].isMouseOver)
                {
                    childObjects[i].MouseExit();
                }
            }
            if(toReturn != this)
                return toReturn;

            mousePos.Y -= (int)scrollOffset.Y;

            for(int i = 0; i < listEntries.Count; i++) {
                if(new Rectangle(listEntries[i].Position, listEntries[i].size).Contains(mousePos)) {
                    toReturn = listEntries[i];
                } else if(listEntries[i].isMouseOver) {
                    listEntries[i].MouseExit();
                }
            }

            return toReturn;
        }

        void SetNewEntryPositions() {
            for(int i = 0; i < listEntries.Count; i++) {
                listEntries[i].Position = new Point(xMargin, entryYOffset + i * (entryHeight + 2 * entryDistance));
            }
        }

        public void ChangeCollection(ICollection<T> newCollection) {
            Debug.WriteLine("Change Collection of SortableList");
            tCollection = newCollection;

            listEntries = new List<SortableListEntry<T>>();
            int i = 0;
            foreach(T t in tCollection)
            {
                var ent = new SortableListEntry<T>(t, ifManager, 
                                                   new Point(xMargin, entryYOffset + i * (entryHeight + 2 * entryDistance)),
                                                   new Point(entryWidth, entryHeight), 
                                                   textColor, 
                                                   width, 
                                                   OnEntryClick, 
                                                   Scroll);                
                listEntries.Add(ent);
                i++;
            }

            ResetMaxOffsetAndHandlePos();            
        }

        void ResetMaxOffsetAndHandlePos() {
            maxYOffset = displaySizeY - entryTotalSizeY;

            int handleHeight;
            if(maxYOffset > 0)
            {
                handleHeight = displaySizeY - 8;
                maxYOffset = 0;
            } else
                handleHeight = 60;//(int)((float)(entryTotalSizeY - 8) * ((float)size.Y / ((float)size.Y + maxYOffset)));
                //TODO handle height idea: handle is the percentage big of the handle max size, that the visible entries area is big of in % of the total entry height
            //maxYOffset *= -1;
            scrollOffset = new Vector2(0, 0);

            scrollbarHandle.Reset(new Point(scrollbarWidth - 8, handleHeight));
        }

        public override void Render(SpriteBatch spriteBatch) {
            RenderAsChild(spriteBatch, Point.Zero);

        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {
            if(!isOpen)
                return;

            sprite?.Render(spriteBatch, new Rectangle(Position + parentPos, size));
            
            Rectangle old = GraphicsDevice.ScissorRectangle;
            GraphicsDevice.ScissorRectangle = new Rectangle(parentPos + Position + new Point(xMargin, yMargin + entryHeight + entryDistance), 
                                                            new Point(entryWidth + scrollbarWidth + scrollbarXOffset, size.Y - 2 * yMargin - entryHeight - entryDistance)); 

            for(int i = 0; i < listEntries.Count; i++)
            {
                listEntries[i].RenderAsChild(spriteBatch, parentPos + Position + new Point(0, (int)scrollOffset.Y));
            }
            GraphicsDevice.ScissorRectangle = old;

            for(int i = 0; i < childObjects.Length; i++)
            {
                if(childObjects[i]?.GetType() != typeof(SortableListEntry<T>))
                    childObjects[i]?.RenderAsChild(spriteBatch, parentPos + Position);
            }

        }

        public void OpenWindow() {
            Open();
        }

        public void CloseWindow() {
            Close();
        }

        private class ScrollBarHandle : UIObject
        {

            private int minHeight = 10;

            private ScrollBarBackground sbBackground;
            private SortableList<T> parent;

            private Color currColor;
            private Color mouseOverColor;
            private Color normalColor;
            private Color mouseDownColor;


            int topPosition { get { return sbBackground.Position.Y + 4; } }
            int bottomPosition { get { return topPosition + sbBackground.size.Y - 8 - size.Y; } }

            private bool dragging = false;
            private int mouseDownOffset;

            public ScrollBarHandle(InterfaceManager ifManager, Point pos, Point size, ScrollBarBackground sbBackground, SortableList<T> parent)
                            : base(false, ifManager, true, pos, size, ifManager.scrollBarHandle)
            {
                this.sbBackground = sbBackground;
                this.parent = parent;

                if(size.Y < minHeight)
                    size.Y = minHeight;

                normalColor = Color.White;
                mouseOverColor = Color.Gray;
                currColor = normalColor;

                ifManager.RegisterUIObjectToHandleInputAsFirstLevel(this);

            }

            public void Reset(Point newSize)
            {
                this.size = newSize;
                if(size.Y < minHeight)
                    size.Y = minHeight;

                this.Y = topPosition;
            }

            public void SetHandlePosition(float factor)
            {
                this.Y = (int)((bottomPosition - topPosition) * factor) + topPosition;
            }

            public override void Update(double deltaTime)
            {

                if(dragging)
                {
                    this.Y = Input.GetMousePosition().Y - mouseDownOffset - parentPos.Y - 4;

                    if(this.Y < topPosition)
                        this.Y = topPosition;
                    if(this.Y > bottomPosition)
                        this.Y = bottomPosition;

                    parent.SetScrollOffset((float)(this.Y - topPosition) / (float)(bottomPosition - topPosition));

                }

                base.Update(deltaTime);
            }

            public override void LeftMouseDown()
            {
                base.LeftMouseDown();
                dragging = true;
                mouseDownOffset = Input.GetMousePosition().Y - parentPos.Y - Position.Y - 4;
            }

            public override void LeftMouseClick(Point clickPos)
            {
                base.LeftMouseClick(clickPos);
                dragging = false;
            }

            public override void MouseEnter()
            {
                base.MouseEnter();
                currColor = mouseOverColor;
            }

            public override void MouseExit()
            {
                base.MouseExit();
                currColor = normalColor;
            }

            public override void ScrollWheelDown()
            {
                parent.ScrollWheelDown();
            }

            public override void ScrollWheelUp()
            {
                parent.ScrollWheelUp();
            }

            public override void Render(SpriteBatch spriteBatch)
            {
                throw new NotImplementedException();
            }

            public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
            {
                sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size), currColor);
            }
        }


        private class ScrollBarBackground : UIObject
        {
            private SortableList<T> parent;
            private Color currColor;
            private Color mouseOverColor;
            private Color normalColor;

            public ScrollBarBackground(InterfaceManager ifManager, Point pos, Point size, SortableList<T> parent)
                                : base(false, ifManager, true, pos, size, ifManager.scrollBarBackground)
            {
                normalColor = currColor = Color.White;
                mouseOverColor = Color.Gray;
                this.parent = parent;
            }

            public override void MouseEnter()
            {
                base.MouseEnter();

            }

            public override void MouseExit()
            {
                base.MouseExit();

            }

            public override void ScrollWheelDown()
            {
                parent.ScrollWheelUp();
            }

            public override void ScrollWheelUp()
            {
                parent.ScrollWheelUp();
            }

            public override void Render(SpriteBatch spriteBatch)
            {
                throw new NotImplementedException();
            }

            public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
            {
                sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size), currColor);
            }
        }

    }
}
