﻿
namespace Barely.Interface {
    public interface IWindow {

        void OpenWindow();

        void CloseWindow();

    }
}
