﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Diagnostics;

namespace Barely.Interface
{
    public class Checkbox : Button
    {
        private Action<bool> valueChangeCallback;
        private bool currentValue;

        private Sprite selectedGraphic;
        private TextLabel description;

        public Checkbox(InterfaceManager ifManager, Point pos, Point size, bool startingValue, Action<bool> valueChangeCallback, string descriptionLabelId, Color textColor, FontSize font, int gapToText = 10) 
                 : base(false, ifManager, pos, size, ifManager.checkboxBackground, null, null)
        {
            currentValue = startingValue;
            this.valueChangeCallback = valueChangeCallback;
            selectedGraphic = ifManager.checkboxSelectedGraphic;
            description = new TextLabel(false, ifManager, font, new Point(pos.X + size.X + gapToText, pos.Y), new Point(100, size.Y), 
                                        descriptionLabelId, textColor, allignY: AllignmentY.Middle, xOverflow: HorOverflow.Overflow);
        }


        public Checkbox(InterfaceManager ifManager, Point pos, Point size, bool startingValue, Action<bool> valueChangeCallback, string descriptionLabelId, int gapToText = 10)
                : this(ifManager, pos, size, startingValue, valueChangeCallback, descriptionLabelId, Color.White, FontSize.Small, gapToText)                 
        {
           
        }


        public override void LeftMouseClick(Point clickPos)
        {
            base.LeftMouseClick(clickPos);
            
            currentValue = !currentValue;
            valueChangeCallback(currentValue);
        }

        public void SetValue(bool newVal) {
            currentValue = newVal;
        }

        public override void Render(SpriteBatch spriteBatch)
        {
            Debug.WriteLine("Checkbox called via Render() instead of RenderAsChild(), why?");
            RenderAsChild(spriteBatch, Point.Zero);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            Rectangle rect = new Rectangle(parentPos + Position, size);
            sprite.Render(spriteBatch, rect, colors[spriteIndex]);

            if (currentValue) {
                Point p = size - selectedGraphic.spriteRect.Size;
                p.X /= 2;
                p.Y /= 2;

                selectedGraphic.Render(spriteBatch, parentPos + Position + p);
            }

            description.RenderAsChild(spriteBatch, parentPos);


        }
    }
}
