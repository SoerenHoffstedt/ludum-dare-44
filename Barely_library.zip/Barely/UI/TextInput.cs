﻿using System;
using System.Text;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Barely.Util;

namespace Barely.Interface {
    public class TextInput : UIObject, IFocusable {

        StringBuilder sb;
        string content;

        int cursorPos;

        bool focused = false;
        SpriteFont font;
        float maxXSize;
        Vector2 textPos;
        Color textColor;

        Action<string> OnEnterPress;
        Action<IFocusable> OnGainFocusCallback;
        Action<IFocusable> OnLooseFocusCallback;

        Sprite cursor;
        float cursorTimer = 0f;
        bool showCursor = false;

        Color color;

        public TextInput(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, Color textColor, FontSize font = FontSize.Small, string startVal = null)
            : base(isFirstLevelObject, ifManager, true, pos, size, ifManager.textInputPanel) {

            this.textColor = textColor;            
            this.font = ifManager.GetFont(font);
            cursor = ifManager.textCursor;
            content = startVal;
            if(startVal != null)
            {
                cursorPos = content.Length;
                sb = new StringBuilder(content);
            } else
            {
                cursorPos = 0;
                sb = new StringBuilder();
            }
            
            EventHandler<TextInputEventArgs> ev = new EventHandler<TextInputEventArgs>(HandleTextInputEvent);          
            Input.AddToTextInputEvent(ev);

            Vector2 si = this.font.MeasureString("Tesy");
            float yDelta = size.Y - si.Y;
            
            textPos = new Vector2(10, yDelta / 2);
            maxXSize = si.X - 10;
            if(si.Y < size.Y)
                Debug.WriteLine("Oh no, the text is too big for the size of the thingy");

            OnGainFocusCallback = ifManager.FocusObject;
            OnLooseFocusCallback = ifManager.UnFocusObject;

            color = Color.White;

            OnMouseEnter += (obj) => { color = Colors.veryLightGray;};
            OnMouseExit += (obj) => color = Color.White;

        }

        public void AddOnEnterAction(Action<String> act) {
            OnEnterPress = act;
        }

        public void SetString(string str)
        {
            content = str;
            sb.Clear();
            sb.Append(str);
            cursorPos = 0;
        }

        void HandleTextInputEvent(object source, TextInputEventArgs args) {
            if(focused)
            {
                
                if(!Char.IsControl(args.Character))
                    sb.Insert(cursorPos++, args.Character);
                
            }
        }

        public override void Update(double deltaTime) {
            base.Update(deltaTime);

            if(focused)
            {
                cursorTimer += (float)deltaTime;
                if(cursorTimer >= 0.5f)
                {
                    showCursor = !showCursor;
                    cursorTimer = 0f;
                }


                if(Input.GetKeyDown(Keys.Left))                
                    cursorPos--;
                
                if(Input.GetKeyDown(Keys.Right))
                    cursorPos++;

                if(cursorPos < 0)
                    cursorPos = 0;
                else if(cursorPos > sb.Length)
                    cursorPos = sb.Length;

                
                if(Input.GetKeyDown(Keys.Back) && cursorPos > 0)
                   sb.Remove(cursorPos-- - 1, 1);

                if (Input.GetKeyDown(Keys.Delete) && cursorPos < sb.Length)
                    sb.Remove(cursorPos, 1);

                if(Input.GetKeyDown(Keys.Enter) || Input.GetKeyDown(Keys.Escape))
                {
                    OnLooseFocus();
                    if(OnEnterPress != null)
                        OnEnterPress(sb.ToString());
                }
                
            }

        }

        public override void LeftMouseClick(Point clickPos) {
            if(!focused)
                OnGainFocus();
            
        }

        public override void Render(SpriteBatch spriteBatch) {

            RenderAsChild(spriteBatch, Point.Zero);
            
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos) {
            string str = sb.ToString();
            sprite.Render(spriteBatch, new Rectangle(Position + parentPos, size),color);
            spriteBatch.DrawString(font, str, new Vector2(Position.X + parentPos.X , Position.Y + parentPos.Y) + textPos, textColor);
            if(focused && showCursor)
            {
                Vector2 strSize = font.MeasureString(str.Substring(0, cursorPos));
                cursor.Render(spriteBatch, new Rectangle(Position + parentPos + new Point((int)strSize.X + (int)textPos.X, 2 + (int)textPos.Y), new Point(2, (int)strSize.Y - 4)));
            }
        }

        public void OnGainFocus() {
            if(focused)
                return;

            focused = true;
            if(OnGainFocusCallback != null)
                OnGainFocusCallback(this);

            cursorPos = sb.Length;
        }

        public void OnLooseFocus() {
            if(!focused)
                return;
            focused = false;
            if (OnEnterPress != null)
                OnEnterPress(sb.ToString());
            if(OnLooseFocusCallback != null)
               OnLooseFocusCallback(this);
        }
    }
}
