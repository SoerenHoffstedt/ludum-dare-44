﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Barely.Interface
{
    public class NumberChanger : UIObject
    {
        private Button plusButton;
        private TextLabel plusLabel;
        private Button minusButton;
        private TextLabel numberLabel;

        private int number;
        private int rangeDown;
        private int rangeUp;
        private int changePerClick;

        private Action<int> onNumberChange;

        public NumberChanger(InterfaceManager ifManager, Point pos, Point size, int startValue, int rangeDown, int rangeUp, Action<int> onNumberChange, int changePerClick = 1)
                        : base(false, ifManager, true, pos, size, ifManager.numberChangerBG)
        {
            this.onNumberChange = onNumberChange;
            number = startValue;
            this.rangeDown = rangeDown;
            this.rangeUp = rangeUp;
            this.changePerClick = changePerClick;

            int margin = 3;
            int buttonSize = ifManager.numberChangerButtonPlus.spriteRect.Size.X;
            int buttonYPosInHalf = ((size.Y / 2) - buttonSize ) / 2;
            plusButton = new Button(false, ifManager, new Point(size.X - buttonSize - margin, buttonYPosInHalf + 2), new Point(buttonSize, buttonSize), ifManager.numberChangerButtonPlus, null, () => {
                number += changePerClick;
                if(number >= rangeUp)
                {
                    number = rangeUp;
                }
                onNumberChange(number);
            });                        

            minusButton = new Button(false, ifManager, new Point(size.X - buttonSize - margin, buttonYPosInHalf + size.Y / 2), new Point(buttonSize, buttonSize), ifManager.numberChangerButtonMinus, null, () => {
                number -= changePerClick;
                if(number <= rangeDown)
                {
                    number = rangeDown;
                }
                onNumberChange(number);
            });            

            SpriteFont font = ifManager.GetFont(FontSize.Normal);
            Vector2 strSize = font.MeasureString("80");
            int yPos = (int)((float)(size.Y - strSize.Y) / 2f);
            int xPos = (int)((size.X - buttonSize - strSize.X) / 2f);
            numberLabel = new TextLabel(false, ifManager, FontSize.Small, new Point(xPos,yPos), (strSize * 2).ToPoint(), startValue.ToString() , Colors.notRealWhite);


            AddChild(new UIObject[] { plusButton, minusButton, numberLabel });

        }

        public void SetValue(int num)
        {
            if(num >= rangeDown && num <= rangeUp)
            {
                number = num;
                onNumberChange(num);
            }
        }

        public override void Render(SpriteBatch spriteBatch)
        {
            throw new NotImplementedException();
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size));
            plusButton.RenderAsChild(spriteBatch, parentPos + Position);
            minusButton.RenderAsChild(spriteBatch, parentPos + Position);
            numberLabel.UpdateText(number.ToString());
            numberLabel.RenderAsChild(spriteBatch, parentPos + Position);
        }
        
    }
}
