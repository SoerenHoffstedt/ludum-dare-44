﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using Barely.Interface;
using Barely.Util;
using System.Xml;
using Microsoft.Xna.Framework.Graphics;

namespace Barely.Interface
{
    public class Dialog : Window
    {
       
        TextLabel message;
        Button buttonOne;
        Button buttonTwo;        

        int margin = 10;

        public Dialog(InterfaceManager ifManager, Point pos, Point size) 
               : base(ifManager, "title", pos, size, false)
        {
            Point buttonSize = new Point((size.X - 3*margin) / 2, 40);
            buttonOne   = new Button(false, ifManager, new Point(margin, size.Y - margin - buttonSize.Y), buttonSize, "buttonOne", Color.White);
            buttonTwo   = new Button(false, ifManager, new Point(2 * margin + buttonSize.X, size.Y - margin - buttonSize.Y), buttonSize, "buttonOne", Color.White);
            message     = new TextLabel(false, ifManager, FontSize.Small, new Point(margin, 50), new Point(size.X - 2 * margin, size.Y - 3 * margin - buttonSize.Y - 50), "TestTest", Color.White);
            isOpen = false;
            AddChild(new UIObject[] { buttonOne, buttonTwo, message });
        }        

        public void OneActionDialog(string headlineId, string textId, Action action, string actionTextId) {
            buttonOne.isOpen = true;
            buttonOne.OnMouseUp = action;
            buttonOne.OnMouseUp += Close;
            buttonOne.UpdateCaptionText(actionTextId);

            buttonTwo.isOpen = false;

            titleBar.ChangeTitle(headlineId);
            message.UpdateText(textId);

            Open();
        }

        public void ActionWithBackButton(string headlineId, string textId, Action action, string actionTextId)
        {
            buttonOne.isOpen = true;
            buttonOne.OnMouseUp = action;
            buttonOne.OnMouseUp += Close;
            buttonOne.UpdateCaptionText(actionTextId);

            buttonTwo.isOpen = true;
            buttonTwo.OnMouseUp = this.Close;
            buttonTwo.UpdateCaptionText("back");

            titleBar.ChangeTitle(headlineId);
            message.UpdateText(textId);

            Open();
        }
        
        public void TwoActionDialog(string headlineId, string textId, Action actionOne, string actionOneTextId, Action actionTwo, string actionTwoTextId)
        {
            buttonOne.isOpen = true;
            buttonOne.OnMouseUp = actionOne;
            buttonOne.OnMouseUp += Close;
            buttonOne.UpdateCaptionText(actionOneTextId);

            buttonTwo.isOpen = true;
            buttonTwo.OnMouseUp = actionTwo;
            buttonTwo.UpdateCaptionText(actionTwoTextId);

            titleBar.ChangeTitle(headlineId);
            message.UpdateText(textId);

            Open();

        }
        /*
        public override void Render(SpriteBatch spriteBatch)
        {
            RenderAsChild(spriteBatch, Point.Zero);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            base.RenderAsChild(spriteBatch, parentPos);
        }*/
    }
}
