﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Barely.Util;
using Microsoft.Xna.Framework;

namespace Barely.Interface
{
    public class DescriptionValuePair : Panel
    {

        TextLabel descLabel;
        TextLabel valueLabel;
        FontSize fontSize = FontSize.Small;
        Color textColor = Color.White;
        float descriptionSizePercentage;
        

        public DescriptionValuePair(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, string desc, string value)
            : this(isFirstLevelObject, ifManager, pos, size, desc, value, FontSize.Small, Color.White, 0.75f)
        {
        }

        public DescriptionValuePair(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, string desc, string value, FontSize fontSize)
            : this(isFirstLevelObject, ifManager, pos, size, desc, value, fontSize, Color.White, 0.75f)
        {
        }

        public DescriptionValuePair(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, string desc, string value, Color textColor)
            : this(isFirstLevelObject, ifManager, pos, size, desc, value, FontSize.Small, textColor, 0.75f)
        {
        }

        public DescriptionValuePair(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, string desc, string value, float descriptionSizePercentage)
            : this(isFirstLevelObject, ifManager, pos, size, desc, value, FontSize.Small, Color.White, descriptionSizePercentage)
        {
        }

        public DescriptionValuePair(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, string desc, string value, FontSize fontSize, Color textColor, float descriptionSizePercentage) 
            : base(isFirstLevelObject, ifManager, pos, size, null, null)
        {
            this.fontSize = fontSize;
            this.textColor = textColor;
            int leftSize = (int)(size.X * descriptionSizePercentage);
            descLabel   = new TextLabel(false, ifManager, this.fontSize, new Point(0, 0), new Point(leftSize, size.Y), desc, this.textColor, AllignmentX.Left, AllignmentY.Middle);
            valueLabel  = new TextLabel(false, ifManager, this.fontSize, new Point(leftSize, 0), new Point(size.X - leftSize, size.Y), value, this.textColor, AllignmentX.Right, AllignmentY.Middle);
            AddChild(new UIObject[] { descLabel, valueLabel });
        }

        public void UpdateDescriptionText(string newDesc, bool getTranslation = true)
        {
            descLabel.UpdateText(newDesc, getTranslation);
        }

        public void UpdateValueText(string newValue, bool getTranslation)
        {
            valueLabel.UpdateText(newValue, getTranslation);
        }
        

    }
}
