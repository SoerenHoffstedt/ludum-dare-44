﻿using System;
using System.Collections.Generic;
using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Barely.Interface
{
    public class ScrollablePanel : Panel 
    {
        List<UIObject> elements;
        GraphicsDevice GraphicsDevice;

        float scrollOffset;
        int biggestY = 0;
        int xMargin = 6;
        int yMargin = 6;
        int sbWidth;
        ScrollBarHandle sbHandle;
        ScrollBarBackground sbBackground;

        public ScrollablePanel(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size, Sprite sprite, int initListSize = 10, int sbWidth = 20, int xMargin = 6, int yMargin = 6) 
                        : base(isFirstLevelObject, ifManager, pos, size, sprite, null)
        {
            this.xMargin = xMargin;
            this.yMargin = yMargin;
            this.sbWidth = sbWidth;
            this.GraphicsDevice = ifManager.GraphicsDevice;
            elements = new List<UIObject>(10);

            sbBackground    = new ScrollBarBackground(ifManager, new Point(size.X - sbWidth - xMargin - 2, yMargin), new Point(sbWidth, size.Y - 2 * yMargin), this);
            sbHandle        = new ScrollBarHandle(ifManager, new Point(size.X - sbWidth - xMargin - 4, yMargin), new Point(sbWidth + 4, 40), sbBackground, this);
            sbHandle.SetHandlePosition(0f);

            AddChild(new UIObject[] { sbBackground, sbHandle });
        }


        public void AddElements(ICollection<UIObject> toAdd)
        {
            foreach(UIObject el in toAdd)
            {
                if (el == null)
                    continue;
                if (el.Position.X + el.size.X > this.size.X - sbWidth - 2 * xMargin)
                   throw new ArgumentException("element is out of bounds of parent panel.");
                if (el.Position.Y + el.size.Y > biggestY - 2 * yMargin)
                    biggestY = el.Position.Y + el.size.Y;
            }
            elements.AddRange(toAdd);
        }

        public void AddElements(UIObject element)
        {            
            if (element.Position.X + element.size.X > this.size.X)
                throw new ArgumentException("element is out of bounds of parent panel.");
            if (element.Position.Y + element.size.Y > biggestY)
                biggestY = element.Position.Y + element.size.Y;
            elements.Add(element);

        }

        public void ClearElements()
        {
            elements.Clear();
            biggestY = 0;
        }

        public void ResetScroll()
        {
            SetScrollOffset(0f);
        }

        private void SetScrollOffset(float factor)
        {
            if ((size.Y - 2 * yMargin - biggestY) > 0)
                scrollOffset = 0;
            else
                scrollOffset = factor * (size.Y - 2 * yMargin - biggestY);
        }

        private void Scroll(int delta)
        {
            int d = 0;
            if (delta < 0)
                d = -30;
            else if (delta > 0)
                d = 30;

            float newOffset = scrollOffset + d;

            if (newOffset > 0)
                newOffset = 0;
            else if (newOffset < size.Y - 2 * yMargin - biggestY)
                newOffset = size.Y - 2 * yMargin - biggestY;

            scrollOffset = newOffset;
            sbHandle.SetHandlePosition(scrollOffset / (size.Y - 2 * yMargin - biggestY), false);
        }

        public override void ScrollWheelDown()
        {
            Scroll(Input.GetMouseWheelDelta());
        }

        public override void ScrollWheelUp()
        {
            Scroll(Input.GetMouseWheelDelta());
        }

        public override UIObject FindMouseOverChild(Point mousePos, ref Point localMousePos)
        {
            if (childObjects == null)
                return this;

            UIObject toReturn = this;
            mousePos -= Position;
            localMousePos = mousePos;

            for (int i = 0; i < childObjects.Length; i++)
            {
                if (childObjects[i] == null)
                    continue;

                if (new Rectangle(childObjects[i].Position, childObjects[i].size).Contains(mousePos))
                {
                    if (childObjects[i].Interactable)
                    {
                        if (childObjects[i].childObjects != null)
                            toReturn = childObjects[i].FindMouseOverChild(mousePos, ref localMousePos);
                        else
                            toReturn = childObjects[i];
                    }
                }
                else if (childObjects[i].isMouseOver)
                {
                    childObjects[i].MouseExit();
                }
            }
            if (toReturn != this)
                return toReturn;

            mousePos.Y -= (int)scrollOffset;

            for (int i = 0; i < elements.Count; i++)
            {
                if (new Rectangle(elements[i].Position, elements[i].size).Contains(mousePos))
                {
                    toReturn = elements[i].FindMouseOverChild(mousePos, ref localMousePos);
                }
                else if (elements[i].isMouseOver)
                {
                    elements[i].MouseExit();
                }
            }

            return toReturn;
        }

        public override void Update(double deltaTime)
        {
            base.Update(deltaTime);
            for(int i = 0; i < elements.Count; i++)
            {
                elements[i].Update(deltaTime);
            }
        }

        public override void Render(SpriteBatch spriteBatch)
        {
            RenderAsChild(spriteBatch, Point.Zero);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            if (!isOpen)
                return;

            sprite?.Render(spriteBatch, new Rectangle(Position + parentPos, size));

            Rectangle old = GraphicsDevice.ScissorRectangle;
            GraphicsDevice.ScissorRectangle = new Rectangle(parentPos + Position + new Point(xMargin, yMargin), size - new Point(xMargin * 2, yMargin*2));
                //+ new Point(xMargin, yMargin + entryHeight + entryDistance),
                  //                                          new Point(entryWidth + scrollbarWidth + scrollbarXOffset, size.Y - 2 * yMargin - entryHeight - entryDistance));

            for (int i = 0; i < elements.Count; i++)
            {
                if (elements[i] == null)
                    continue;
                elements[i].RenderAsChild(spriteBatch, parentPos + Position + new Point(0, (int)scrollOffset));
            }

            for (int i = 0; i < childObjects.Length; i++)
            {                
                childObjects[i]?.RenderAsChild(spriteBatch, parentPos + Position);
            }

            GraphicsDevice.ScissorRectangle = old;
        }

        private class ScrollBarHandle : UIObject
        {

            bool isActive = true;

            private int minHeight = 10;

            private ScrollBarBackground sbBackground;
            private ScrollablePanel parent;

            private Color currColor;
            private Color normalColor = Color.White;
            private Color mouseOverColor = Colors.veryLightGray;
            private Color mouseDownColor = Colors.lightGray;


            int topPosition { get { return sbBackground.Position.Y + 4; } }
            int bottomPosition { get { return topPosition + sbBackground.size.Y - 8 - size.Y; } }

            private bool dragging = false;
            private int mouseDownOffset;

            public ScrollBarHandle(InterfaceManager ifManager, Point pos, Point size, ScrollBarBackground sbBackground, ScrollablePanel parent)
                            : base(false, ifManager, true, pos, size, ifManager.scrollBarHandle)
            {
                this.sbBackground = sbBackground;
                this.parent = parent;

                if (size.Y < minHeight)
                    size.Y = minHeight;
                
                currColor = normalColor;
                ifManager.RegisterUIObjectToHandleInputAsFirstLevel(this);
            }

            public void Reset(Point newSize)
            {
                this.size = newSize;
                if (size.Y < minHeight)
                    size.Y = minHeight;

                this.Y = topPosition;
            }

            public void SetHandlePosition(float factor, bool callback = true)
            {
                this.Y = (int)((bottomPosition - topPosition) * factor) + topPosition;
                if(callback)
                    parent.SetScrollOffset(factor);
            }

            public override void Update(double deltaTime)
            {

                if (dragging)
                {
                    this.Y = Input.GetMousePosition().Y - mouseDownOffset - parentPos.Y - 4;

                    if (this.Y < topPosition)
                        this.Y = topPosition;
                    if (this.Y > bottomPosition)
                        this.Y = bottomPosition;

                    parent.SetScrollOffset((float)(this.Y - topPosition) / (float)(bottomPosition - topPosition));

                }

                base.Update(deltaTime);
            }

            public override void LeftMouseDown()
            {
                base.LeftMouseDown();
                currColor = mouseDownColor;
                dragging = true;
                mouseDownOffset = Input.GetMousePosition().Y - parentPos.Y - Position.Y - 4;
            }            

            public override void LeftMouseClick(Point clickPos)
            {
                base.LeftMouseClick(clickPos);
                dragging = false;
                currColor = normalColor;
            }

            public override void MouseEnter()
            {
                base.MouseEnter();
                currColor = mouseOverColor;
            }

            public override void MouseExit()
            {
                base.MouseExit();
                currColor = normalColor;
            }

            public override void ScrollWheelDown()
            {
                parent.ScrollWheelDown();
            }

            public override void ScrollWheelUp()
            {
                parent.ScrollWheelUp();
            }

            public override void Render(SpriteBatch spriteBatch)
            {
                throw new NotImplementedException();
            }

            public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
            {
                sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size), currColor);
            }
        }

        private class ScrollBarBackground : UIObject
        {
            private ScrollablePanel parent;
            private Color currColor;
            private Color mouseOverColor;
            private Color normalColor;

            public ScrollBarBackground(InterfaceManager ifManager, Point pos, Point size, ScrollablePanel parent)
                                : base(false, ifManager, true, pos, size, ifManager.scrollBarBackground)
            {
                normalColor = currColor = Color.White;
                mouseOverColor = Color.Gray;
                this.parent = parent;
            }

            public override void MouseEnter()
            {
                base.MouseEnter();

            }

            public override void MouseExit()
            {
                base.MouseExit();

            }

            public override void ScrollWheelDown()
            {
                parent.ScrollWheelUp();
            }

            public override void ScrollWheelUp()
            {
                parent.ScrollWheelUp();
            }

            public override void Render(SpriteBatch spriteBatch)
            {
                throw new NotImplementedException();
            }

            public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
            {
                sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size), currColor);
            }
        }


    }
}
