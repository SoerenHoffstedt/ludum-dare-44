﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Barely.Util;
using System;
using System.Diagnostics;
using System.Text;

namespace Barely.Interface {

    public abstract class UIObject {

        protected bool interactable;
        public Point Position { get { return position; } set { 
            position = value;  
            if(childObjects != null) {
                for(int i = 0; i < childObjects.Length; i++) {
                    if(childObjects[i] != null)
                        childObjects[i].parentPos = value;
                }
            }
        } }

        private Point position;
        public Point parentPos;
        public Point size;
        public Sprite sprite;
        public Point padding;

        public int X { get { return Position.X; } set { Position = new Point(value, Position.Y); } }
        public int Y { get { return Position.Y; } set { Position = new Point(Position.X, value); } }

        public bool isOpen;
        public bool isOpening;
        public bool isClosing;
        public bool Interactable { get { return isOpen && interactable; } set { interactable = value; } }
        public bool genericFlag = false;

        public UIObject[] childObjects;
        public UIObject[] ChildObjects { get { return childObjects; } }

        public Action<UIObject> OnMouseEnter;
        public Action<UIObject> OnMouseExit;

        public Action<UIObject> OnOpen;
        public Action<UIObject> OnClose;

        public bool isMouseOver = false;
        public bool isMouseDown = false;

        public string tooltipID = null;
        public bool HasTooltip { get { return tooltipID != null; } }
        private double tooltipTimer = 0.0;

        public static Func<double> tooltipTime;
        public static Action<UIObject> ShowTooltip;

        public UIObject(bool isFirstLevelObject, InterfaceManager ifManager, bool interactable, Point pos, Point size, Sprite sprite) {
            this.interactable = interactable;
            this.Position = pos;
            this.parentPos = Point.Zero;
            this.size = size;
            this.sprite = sprite;
            this.isOpen = true;
            this.padding = Point.Zero;

            if (isFirstLevelObject)
            {
                ifManager.RegisterUIObject(this);                
            }
        }        

        public virtual void Update(double deltaTime) {

            if(isMouseOver && HasTooltip && tooltipTimer < tooltipTime())
            {
                tooltipTimer += deltaTime;
                if(tooltipTimer >= tooltipTime())
                {
                    ShowTooltip(this);   
                }

            }

            if(childObjects != null)
            {
                for(int i = 0; i < childObjects.Length; i++)
                {
                    if(childObjects[i] != null)
                        childObjects[i].Update(deltaTime);
                }
            }
        }

        /// <summary>
        /// Gives the Child back that the mouse is over, if not over a child or no child available it returns itself.
        /// </summary>
        /// <param name="mousePos"></param>
        /// <returns></returns>
        public virtual UIObject FindMouseOverChild(Point mousePos, ref Point localMousePos) {
            if(childObjects == null)
            {
                return this;
            }
            var toReturn = this;
            mousePos -= Position;
            localMousePos = mousePos;
            for(int i = 0; i < childObjects.Length; i++)
            {
                if(childObjects[i] == null || childObjects[i].isOpen == false)
                    continue;

                if(new Rectangle(childObjects[i].Position, childObjects[i].size).Contains(mousePos))
                {
                    if(childObjects[i].Interactable)
                    {
                        if(childObjects[i].childObjects != null)
                            toReturn = childObjects[i].FindMouseOverChild(mousePos, ref localMousePos);
                        else
                            toReturn = childObjects[i];
                    }
                } else if(childObjects[i].isMouseOver)
                {
                    childObjects[i].MouseExit();
                }
            }

            return toReturn;
        }

        public virtual void AddChild(UIObject[] newChilds) {
            
            if (childObjects == null)
            {
                childObjects = newChilds;
            } else {
                UIObject[] newArr = new UIObject[newChilds.Length + childObjects.Length];
                for(int i = 0; i < newChilds.Length; i++)
                {
                    newArr[i] = newChilds[i];
                }
                for(int i = newChilds.Length; i < newChilds.Length + childObjects.Length; i++)
                {
                    newArr[i] = childObjects[i - newChilds.Length];
                }

                childObjects = newArr;
            }
        }

        public virtual void AddChild(UIObject newChild) {
            if(childObjects == null)
            {
                childObjects = new UIObject[1];
                childObjects[0] = newChild;
            } else
            {
                UIObject[] newArr = new UIObject[childObjects.Length + 1];
               
                for(int i = 1; i < childObjects.Length + 1; i++)
                {
                    newArr[i] = childObjects[i-1];
                }
                newArr[0] = newChild;

                childObjects = newArr;
            }
        }

        public virtual void RemoveChild(UIObject obj) {
            for(int i = 0; i < childObjects.Length; i++)
            {
                if(childObjects[i] != null && childObjects[i].Equals(obj))
                {
                    UIObject[] newArr = new UIObject[childObjects.Length - 1];

                    for(int k = 0; k < i; k++)
                    {
                        newArr[k] = childObjects[k];
                    }
                    for(int k = i; k < childObjects.Length - 1; k++)
                    {
                        newArr[k] = childObjects[k + 1];
                    }
                    childObjects = newArr;
                    return;
                }
            }
            
        }

        public void SetParentPos(Point parentPosition) {
            this.parentPos = parentPosition;
            if (childObjects == null)
                return;
            foreach(UIObject o in childObjects) {
                o?.SetParentPos(parentPos + Position);
            }
        }

        public void SetOnMouseEnterExit(Action<UIObject> onMouseEnter, Action<UIObject> onMouseExit) {
            this.OnMouseEnter = onMouseEnter;
            this.OnMouseExit = onMouseExit;
        }

        public void SetOnOpenClose(Action<UIObject> onOpen, Action<UIObject> onClose) {
            this.OnOpen = onOpen;
            this.OnClose = onClose;
        }

        public void OpenCloseTrigger() {
            if(isOpen)
                Close();
            else
                Open();
        }

        public void Open() {
            if(!isOpen)
            {
                OnOpen?.Invoke(this);
                isOpen = true;
            }
        }

        public void Close() {
            if(isOpen)
            {
                OnClose?.Invoke(this);
                isOpen = false;
            }
        }

        public abstract void Render(SpriteBatch spriteBatch);

        public abstract void RenderAsChild(SpriteBatch spriteBatch, Point parentPos);

        public virtual void MouseOver() {

        }

        public virtual void MouseEnter() {
            isMouseOver = true;
            OnMouseEnter?.Invoke(this);

        }

        public virtual void LeftMouseClick(Point clickPos) {
            isMouseDown = false;
        }

        public virtual void LeftMouseDown() {
            isMouseDown = true;
        }

        public virtual void LeftMousePressed() {

        }


        public virtual void RightMouseClick() {
            //Debug.WriteLine($"Rigth Mosue Click {name}");
        }

        public virtual void RightMouseDown() {
            //Debug.WriteLine($"Rigth Mosue Click {name}");
        }


        public virtual void RightMousePressed() {
            //Debug.WriteLine($"Rigth Mosue Click {name}");
        }

        public virtual void ScrollWheelUp() {

        }

        public virtual void ScrollWheelDown()
        {

        }

        public virtual void MouseExit() {
            isMouseOver = false;
            OnMouseExit?.Invoke(this);

            if (HasTooltip)
            {
                ShowTooltip(null);
                tooltipTimer = 0.0;
            }
        }


        public static string WrapText(SpriteFont font, string text, Point maxSize) {
            string[] words = text.Split(' ');
            StringBuilder sb = new StringBuilder();
            float maxLineWidth = maxSize.X;
            float maxLineHeight = maxSize.Y;
            float lineWidth = 0f;
            int lines = 0;
            float lineHeight = font.MeasureString("Test Word").Y;
            float spaceWidth = font.MeasureString(" ").X;
            
            foreach(string word in words)
            {                
                
                Vector2 size = font.MeasureString(word);
                
                if(word.Contains("\n"))
                {                    
                    sb.Append(word + " ");
                    lineWidth = size.X + spaceWidth;
                    lines++;
                } else if(lineWidth + size.X < maxLineWidth)
                {
                    sb.Append(word + " ");
                    lineWidth += size.X + spaceWidth;
                } else
                {
                    if(size.X > maxLineWidth)
                    {
                        if(sb.ToString() == "")
                        {
                            sb.Append(WrapText(font, word.Insert(word.Length / 2, " ") + " ", maxSize));
                        } else
                        {
                            sb.Append("\n" + WrapText(font, word.Insert(word.Length / 2, " ") + " ", maxSize));
                        }
                    } else
                    {
                        if((lines + 1) * lineHeight >= maxLineHeight)
                        {
                            Debug.WriteLine($"Error in Wrapping text, Height for string not big enough, is cut");
                            return sb.ToString();
                        }
                        sb.Append("\n" + word + " ");
                        lineWidth = size.X + spaceWidth;
                        lines++;
                    }
                }
            }

            return sb.ToString();
        }

    }

}
