﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Barely.Interface {
    class MovingLabel {

        
        public float length;
        public float timer;
        public int horMovement;
        public int origXPos;
        public int multiplier;

        public MovingLabel(float length, int x) {
            horMovement = 15;
            this.length = length;
            timer = 0f;
            origXPos = x;
            multiplier = 1;
        }
        


        //Update Damage Number Labels
        /*if(damageLabels.Count > 0) {
            for(int i = 0; i < damageLabels.Count; i++) {

                DamageLabelHelp helper = damageLabelHelpers[damageLabels[i]];
                if (helper.timer < helper.length)
                {
                    int delta = (int)(deltaTime * 100.0);
                    //damageLabels[i].position.X += delta * helper.multiplier * 1;
                    damageLabels[i].position.Y += -2 * delta; //* Math.Abs(damageLabels[i].position.X - helper.origXPos) / 10;

                    if (damageLabels[i].position.X > helper.origXPos + helper.horMovement || damageLabels[i].position.X < helper.origXPos - helper.horMovement)
                    {
                        helper.multiplier *= -1;
                    }

                    helper.timer += (float)deltaTime;

                }
                else {
                    damageLabelHelpers.Remove(damageLabels[i]);
                    damageLabels.Remove(damageLabels[i]);
                }
            }
        }*/
    }
}
