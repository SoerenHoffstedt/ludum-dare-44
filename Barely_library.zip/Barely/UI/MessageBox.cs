﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Barely.Util;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections;

namespace Barely.Interface
{
    public class MessageBox : Panel
    {
        Sprite background;
        int maxElements;
        LinkedList<TextLabel> labels;
        Stack<TextLabel> unusedLabels;
        Dictionary<TextLabel, double> labelTimers;
        double showLength;

        int entryHeight = 20;
        FontSize font = FontSize.Small;
        Color textColor = Color.White;
        Color bgColor = new Color(50, 50, 50, 128);
        InterfaceManager ifManager;

        public MessageBox(bool isFirstLevelObject, InterfaceManager ifManager, Point pos, Point size) 
                   : base(isFirstLevelObject, ifManager, pos, size, null, null)
        {            
            maxElements = 10;
            showLength = 3.0;
            labels = new LinkedList<TextLabel>();
            unusedLabels = new Stack<TextLabel>(maxElements);
            labelTimers = new Dictionary<TextLabel, double>(maxElements);
            background = ifManager.listSelectedBackground;

            this.ifManager = ifManager;    
            interactable = false;
        }

        public void ShowMessage(string text, bool getTranslation = true) {
            //create labels with position 0,0 and set position via renderaschild parameter
            TextLabel l;
            string t = getTranslation ? Texts.Get(text) : text;
            if(unusedLabels.Count > 0)
            {
                l = unusedLabels.Pop();
                l.UpdateText(t);
            } else {
                l = new TextLabel(false, ifManager, font, new Point(0, 0), new Point(size.X, entryHeight), t, textColor, AllignmentX.Left, AllignmentY.Middle);    
            }
            labels.AddFirst(l);
            labelTimers.Add(l, 0.0);
        }

        public override void Update(double deltaTime)
        {
            //dont need base call, because i dont insert children

            var node = labels.First;
            while(node != null) {
                TextLabel label = node.Value;
                var next = node.Next;
                
                labelTimers[label] += deltaTime;
                if(labelTimers[label] >= showLength)
                {
                    labels.Remove(node);
                    labelTimers.Remove(label);
                    unusedLabels.Push(label);
                }

                node = next;
            }
            
        }

        public override void Render(SpriteBatch spriteBatch)
        {
            RenderAsChild(spriteBatch, Point.Zero);
        }

        public override void RenderAsChild(SpriteBatch spriteBatch, Point parentPos)
        {
            sprite?.Render(spriteBatch, new Rectangle(parentPos + Position, size));

            Point entrySize = new Point(size.X, entryHeight);
            int drawnCount = 0;

            foreach(TextLabel label in labels) {
                if(label != null)
                {
                    Point pos = parentPos + Position + new Point(0, drawnCount * entryHeight + drawnCount);
                    background.Render(spriteBatch, new Rectangle(pos, entrySize), bgColor);
                    label.RenderAsChild(spriteBatch, pos + new Point(2,0));
                    drawnCount++;
                }
            }
        }
    }
}
